<?php
/**
 * Automation MCP - Página de Habilidades
 *
 * @package AutomationMCP
 * @author  alissondsgn
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$keys     = AMCP_Auth::list_keys();
$registry = AMCP_Abilities::get_registry();

// Chave selecionada (via GET ou primeira ativa)
$selected_key_id = absint( $_GET['key_id'] ?? 0 );
if ( ! $selected_key_id && ! empty( $keys ) ) {
    foreach ( $keys as $k ) {
        if ( $k['status'] === 'active' ) {
            $selected_key_id = (int) $k['id'];
            break;
        }
    }
}

// Habilidades atuais da chave selecionada
$current_abilities = array();
if ( $selected_key_id ) {
    foreach ( $keys as $k ) {
        if ( (int) $k['id'] === $selected_key_id ) {
            $decoded = json_decode( $k['abilities'], true );
            $current_abilities = is_array( $decoded ) ? $decoded : array();
            break;
        }
    }
}
?>

<div class="wrap amcp-wrap">
    <h1>Habilidades</h1>
    <hr class="wp-header-end">

    <?php settings_errors( 'amcp_messages' ); ?>

    <?php if ( empty( $keys ) ) : ?>
        <div class="notice notice-warning">
            <p>Nenhuma chave API encontrada. <a href="<?php echo esc_url( admin_url( 'admin.php?page=amcp-api-keys' ) ); ?>">Crie uma chave</a> primeiro.</p>
        </div>
    <?php else : ?>

        <div class="amcp-abilities-header">
            <form method="get" action="" id="amcp-key-selector-form">
                <input type="hidden" name="page" value="amcp-abilities">
                <label for="amcp-key-selector"><strong>Selecionar Chave API:</strong></label>
                <select id="amcp-key-selector" name="key_id">
                    <?php foreach ( $keys as $k ) : ?>
                        <?php
                        $status_label = $k['status'] === 'active' ? '' : ' (Revogada)';
                        ?>
                        <option value="<?php echo esc_attr( $k['id'] ); ?>"
                            <?php selected( $selected_key_id, (int) $k['id'] ); ?>>
                            <?php echo esc_html( $k['name'] . ' — ' . $k['key_prefix'] . '••••' . $status_label ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <?php if ( $selected_key_id ) : ?>
            <form method="post" action="">
                <input type="hidden" name="amcp_action" value="save_abilities">
                <input type="hidden" name="abilities_key_id" value="<?php echo esc_attr( $selected_key_id ); ?>">
                <?php wp_nonce_field( 'amcp_save_abilities', 'amcp_nonce' ); ?>

                <div class="amcp-abilities-grid">
                    <?php foreach ( $registry as $cat_key => $category ) : ?>
                        <div class="amcp-ability-card <?php echo ! empty( $category['dangerous'] ) ? 'amcp-ability-card--dangerous' : ''; ?>">
                            <div class="amcp-ability-card-header">
                                <h3>
                                    <?php echo esc_html( $category['label'] ); ?>
                                    <?php if ( ! empty( $category['dangerous'] ) ) : ?>
                                        <span class="amcp-badge amcp-badge--danger">Perigoso</span>
                                    <?php endif; ?>
                                </h3>
                                <label class="amcp-select-all-label">
                                    <input type="checkbox" class="amcp-select-all-cat" data-category="<?php echo esc_attr( $cat_key ); ?>">
                                    Selecionar tudo
                                </label>
                            </div>

                            <?php if ( ! empty( $category['dangerous'] ) ) : ?>
                                <div class="amcp-warning-box">
                                    <strong>Atenção:</strong> Estas habilidades concedem acesso de baixo nível ao servidor e banco de dados. Use com extrema cautela.
                                </div>
                            <?php endif; ?>

                            <div class="amcp-ability-list">
                                <?php foreach ( $category['tools'] as $tool_key => $tool_label ) : ?>
                                    <label class="amcp-ability-item" data-category="<?php echo esc_attr( $cat_key ); ?>">
                                        <input type="checkbox"
                                               name="abilities[]"
                                               value="<?php echo esc_attr( $tool_key ); ?>"
                                               <?php checked( in_array( $tool_key, $current_abilities, true ) ); ?>>
                                        <div class="amcp-ability-info">
                                            <span class="amcp-ability-name"><?php echo esc_html( $tool_key ); ?></span>
                                            <span class="amcp-ability-desc"><?php echo esc_html( $tool_label ); ?></span>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary">Salvar Configurações</button>
                </p>
            </form>
        <?php endif; ?>

    <?php endif; ?>
</div>
