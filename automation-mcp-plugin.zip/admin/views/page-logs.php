<?php
/**
 * Automation MCP - Página de Registros de Atividade
 *
 * @package AutomationMCP
 * @author  alissondsgn
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$keys         = AMCP_Auth::list_keys();
$all_actions  = AMCP_Abilities::get_all_tool_names();

// Filtros da URL
$filter_key    = absint( $_GET['filter_key'] ?? 0 );
$filter_action = sanitize_text_field( $_GET['filter_action'] ?? '' );
$filter_period = sanitize_text_field( $_GET['filter_period'] ?? '7d' );
$current_page  = max( 1, absint( $_GET['paged'] ?? 1 ) );

// Calcular data "since" com base no período
$since = '';
switch ( $filter_period ) {
    case '24h':
        $since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
        break;
    case '7d':
        $since = gmdate( 'Y-m-d H:i:s', time() - ( 7 * DAY_IN_SECONDS ) );
        break;
    case '30d':
        $since = gmdate( 'Y-m-d H:i:s', time() - ( 30 * DAY_IN_SECONDS ) );
        break;
    case 'all':
    default:
        $since = '';
        break;
}

$filters = array();
if ( $filter_key )    $filters['api_key_id'] = $filter_key;
if ( $filter_action ) $filters['action']     = $filter_action;
if ( $since )         $filters['since']      = $since;

$result = AMCP_Logger::query( $filters, $current_page, 50 );
$logs   = $result['items'];
$total  = $result['total'];
$pages  = $result['pages'];

// Mapa de status para exibição
$status_labels = array(
    'success' => array( 'label' => 'SUCESSO', 'class' => 'amcp-badge--success' ),
    'denied'  => array( 'label' => 'NEGADO',  'class' => 'amcp-badge--danger' ),
    'error'   => array( 'label' => 'ERRO',    'class' => 'amcp-badge--warning' ),
);
?>

<div class="wrap amcp-wrap">
    <h1>Registros de Atividade</h1>
    <hr class="wp-header-end">

    <?php settings_errors( 'amcp_messages' ); ?>

    <!-- Barra de filtros -->
    <div class="amcp-filter-bar">
        <form method="get" action="">
            <input type="hidden" name="page" value="amcp-logs">

            <div class="amcp-filter-group">
                <label for="filter_key">Cliente:</label>
                <select id="filter_key" name="filter_key">
                    <option value="0">Todos</option>
                    <?php foreach ( $keys as $k ) : ?>
                        <option value="<?php echo esc_attr( $k['id'] ); ?>"
                            <?php selected( $filter_key, (int) $k['id'] ); ?>>
                            <?php echo esc_html( $k['name'] ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="amcp-filter-group">
                <label for="filter_action">Ação:</label>
                <select id="filter_action" name="filter_action">
                    <option value="">Todas</option>
                    <?php foreach ( $all_actions as $action_name ) : ?>
                        <option value="<?php echo esc_attr( $action_name ); ?>"
                            <?php selected( $filter_action, $action_name ); ?>>
                            <?php echo esc_html( $action_name ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="amcp-filter-group">
                <label for="filter_period">Período:</label>
                <select id="filter_period" name="filter_period">
                    <option value="24h" <?php selected( $filter_period, '24h' ); ?>>Últimas 24 horas</option>
                    <option value="7d" <?php selected( $filter_period, '7d' ); ?>>Últimos 7 dias</option>
                    <option value="30d" <?php selected( $filter_period, '30d' ); ?>>Últimos 30 dias</option>
                    <option value="all" <?php selected( $filter_period, 'all' ); ?>>Todo o período</option>
                </select>
            </div>

            <button type="submit" class="button">Filtrar</button>
        </form>
    </div>

    <!-- Resumo -->
    <p class="amcp-log-summary">
        <?php
        printf(
            'Exibindo %d de %d registro(s) — Página %d de %d',
            count( $logs ),
            $total,
            $current_page,
            max( 1, $pages )
        );
        ?>
    </p>

    <!-- Tabela de logs -->
    <table class="widefat striped amcp-logs-table">
        <thead>
            <tr>
                <th>Hora</th>
                <th>Status</th>
                <th>Ação</th>
                <th>Descrição</th>
                <th>Cliente</th>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $logs ) ) : ?>
                <tr>
                    <td colspan="5" class="amcp-empty-state">
                        Nenhum registro encontrado para os filtros selecionados.
                    </td>
                </tr>
            <?php else : ?>
                <?php foreach ( $logs as $log ) : ?>
                    <?php
                    $status_info = $status_labels[ $log['result_status'] ] ?? array(
                        'label' => strtoupper( $log['result_status'] ),
                        'class' => '',
                    );
                    $time_display = date_i18n( 'd/m/Y H:i:s', strtotime( $log['created_at'] ) );
                    $client_name  = ! empty( $log['key_name'] ) ? $log['key_name'] : 'Chave #' . $log['api_key_id'];
                    $description  = ! empty( $log['result_message'] ) ? $log['result_message'] : '—';
                    ?>
                    <tr>
                        <td class="amcp-log-time">
                            <span title="<?php echo esc_attr( $log['created_at'] ); ?>">
                                <?php echo esc_html( $time_display ); ?>
                            </span>
                        </td>
                        <td>
                            <span class="amcp-badge <?php echo esc_attr( $status_info['class'] ); ?>">
                                <?php echo esc_html( $status_info['label'] ); ?>
                            </span>
                        </td>
                        <td>
                            <code><?php echo esc_html( $log['action'] ); ?></code>
                        </td>
                        <td class="amcp-log-desc">
                            <?php echo esc_html( wp_trim_words( $description, 20, '...' ) ); ?>
                        </td>
                        <td><?php echo esc_html( $client_name ); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Paginação -->
    <?php if ( $pages > 1 ) : ?>
        <div class="amcp-pagination">
            <?php
            $base_url = add_query_arg( array(
                'page'          => 'amcp-logs',
                'filter_key'    => $filter_key,
                'filter_action' => $filter_action,
                'filter_period' => $filter_period,
            ), admin_url( 'admin.php' ) );

            // Primeira página
            if ( $current_page > 1 ) : ?>
                <a href="<?php echo esc_url( add_query_arg( 'paged', 1, $base_url ) ); ?>" class="button">&laquo; Primeira</a>
                <a href="<?php echo esc_url( add_query_arg( 'paged', $current_page - 1, $base_url ) ); ?>" class="button">&lsaquo; Anterior</a>
            <?php endif; ?>

            <span class="amcp-pagination-info">
                Página <?php echo esc_html( $current_page ); ?> de <?php echo esc_html( $pages ); ?>
            </span>

            <?php if ( $current_page < $pages ) : ?>
                <a href="<?php echo esc_url( add_query_arg( 'paged', $current_page + 1, $base_url ) ); ?>" class="button">Próxima &rsaquo;</a>
                <a href="<?php echo esc_url( add_query_arg( 'paged', $pages, $base_url ) ); ?>" class="button">Última &raquo;</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
