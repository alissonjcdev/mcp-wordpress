<?php
/**
 * Automation MCP - Página de Chaves API
 *
 * @package AutomationMCP
 * @author  alissondsgn
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$keys     = AMCP_Auth::list_keys();
$registry = AMCP_Abilities::get_registry();
$admins   = get_users( array( 'role' => 'administrator' ) );
$new_key  = get_transient( 'amcp_new_key_' . get_current_user_id() );

if ( $new_key ) {
    delete_transient( 'amcp_new_key_' . get_current_user_id() );
}
?>

<div class="wrap amcp-wrap">
    <h1 class="wp-heading-inline">Chaves API</h1>
    <button type="button" id="amcp-toggle-new-key" class="page-title-action">Nova Chave API</button>
    <hr class="wp-header-end">

    <?php settings_errors( 'amcp_messages' ); ?>

    <?php if ( $new_key ) : ?>
        <div class="amcp-new-key-notice">
            <h3>Sua nova chave API foi criada</h3>
            <p>Copie a chave abaixo. <strong>Ela não será exibida novamente.</strong></p>
            <div class="amcp-key-display">
                <code id="amcp-full-key"><?php echo esc_html( $new_key ); ?></code>
                <button type="button" class="button amcp-copy-key" data-target="amcp-full-key">Copiar</button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Formulário inline para nova chave -->
    <div id="amcp-new-key-form" class="amcp-inline-form" style="display:none;">
        <h2>Criar Nova Chave API</h2>
        <form method="post" action="">
            <input type="hidden" name="amcp_action" value="create_key">
            <?php wp_nonce_field( 'amcp_create_key', 'amcp_nonce' ); ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="key_name">Nome do Cliente</label></th>
                    <td>
                        <input type="text" id="key_name" name="key_name" class="regular-text" required
                               placeholder="Ex: Claude Desktop, Cursor IDE...">
                        <p class="description">Identificador para esta chave API.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="key_user_id">Usuário WordPress</label></th>
                    <td>
                        <select id="key_user_id" name="key_user_id" required>
                            <option value="">— Selecionar administrador —</option>
                            <?php foreach ( $admins as $admin ) : ?>
                                <option value="<?php echo esc_attr( $admin->ID ); ?>">
                                    <?php echo esc_html( $admin->display_name . ' (' . $admin->user_email . ')' ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">As ações serão executadas como este usuário.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Habilidades</th>
                    <td>
                        <?php foreach ( $registry as $cat_key => $category ) : ?>
                            <div class="amcp-ability-group <?php echo ! empty( $category['dangerous'] ) ? 'amcp-ability-group--dangerous' : ''; ?>">
                                <h4>
                                    <?php echo esc_html( $category['label'] ); ?>
                                    <?php if ( ! empty( $category['dangerous'] ) ) : ?>
                                        <span class="amcp-badge amcp-badge--danger">Perigoso</span>
                                    <?php endif; ?>
                                </h4>
                                <?php if ( ! empty( $category['dangerous'] ) ) : ?>
                                    <div class="amcp-warning-box">
                                        <strong>Atenção:</strong> Estas habilidades concedem acesso de baixo nível ao servidor. Habilite apenas se necessário e para clientes confiáveis.
                                    </div>
                                <?php endif; ?>
                                <div class="amcp-ability-checkboxes">
                                    <?php foreach ( $category['tools'] as $tool_key => $tool_label ) : ?>
                                        <label class="amcp-ability-checkbox">
                                            <input type="checkbox" name="key_abilities[]" value="<?php echo esc_attr( $tool_key ); ?>">
                                            <span class="amcp-ability-name"><?php echo esc_html( $tool_key ); ?></span>
                                            <span class="amcp-ability-desc"><?php echo esc_html( $tool_label ); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" class="button button-primary">Criar Chave API</button>
                <button type="button" class="button amcp-cancel-new-key">Cancelar</button>
            </p>
        </form>
    </div>

    <!-- Tabela de chaves -->
    <table class="widefat striped amcp-keys-table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Chave</th>
                <th>Usuário Vinculado</th>
                <th>Último Uso</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $keys ) ) : ?>
                <tr>
                    <td colspan="6" class="amcp-empty-state">
                        Nenhuma chave API encontrada. Clique em "Nova Chave API" para criar uma.
                    </td>
                </tr>
            <?php else : ?>
                <?php foreach ( $keys as $key ) : ?>
                    <?php
                    $user = get_userdata( $key['user_id'] );
                    $user_display = $user ? $user->display_name : 'Usuário #' . $key['user_id'];
                    $prefix = esc_html( $key['key_prefix'] );
                    $last4 = ''; // O hash não permite recuperar os últimos 4 caracteres reais
                    $masked_key = $prefix . '••••••••';
                    $is_active = $key['status'] === 'active';
                    $last_used = $key['last_used_at']
                        ? date_i18n( 'd/m/Y H:i', strtotime( $key['last_used_at'] ) )
                        : 'Nunca';
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html( $key['name'] ); ?></strong>
                            <br>
                            <small class="amcp-text-muted">Criada em <?php echo date_i18n( 'd/m/Y', strtotime( $key['created_at'] ) ); ?></small>
                        </td>
                        <td>
                            <code class="amcp-masked-key"><?php echo esc_html( $masked_key ); ?></code>
                        </td>
                        <td><?php echo esc_html( $user_display ); ?></td>
                        <td><?php echo esc_html( $last_used ); ?></td>
                        <td>
                            <?php if ( $is_active ) : ?>
                                <span class="amcp-badge amcp-badge--success">Ativa</span>
                            <?php else : ?>
                                <span class="amcp-badge amcp-badge--danger">Revogada</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( $is_active ) : ?>
                                <form method="post" action="" class="amcp-inline-action">
                                    <input type="hidden" name="amcp_action" value="revoke_key">
                                    <input type="hidden" name="key_id" value="<?php echo esc_attr( $key['id'] ); ?>">
                                    <?php wp_nonce_field( 'amcp_revoke_key', 'amcp_nonce' ); ?>
                                    <button type="submit" class="button button-link-delete amcp-confirm-revoke"
                                            data-name="<?php echo esc_attr( $key['name'] ); ?>">
                                        Revogar
                                    </button>
                                </form>
                            <?php else : ?>
                                <span class="amcp-text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
