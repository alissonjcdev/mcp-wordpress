<?php
/**
 * Automation MCP - Página de Configurações
 *
 * @package AutomationMCP
 * @author  alissondsgn
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$enabled         = get_option( 'amcp_enabled', '1' );
$log_retention   = get_option( 'amcp_log_retention', '30' );
$rate_limit      = get_option( 'amcp_rate_limit', '100' );
$protected_raw   = get_option( 'amcp_protected_paths', '[]' );
$protected_paths = json_decode( $protected_raw, true );
$protected_text  = is_array( $protected_paths ) ? implode( "\n", $protected_paths ) : '';
$rest_endpoint   = site_url( '/wp-json/automation-mcp/v1/' );
?>

<div class="wrap amcp-wrap">
    <h1>Configurações</h1>
    <hr class="wp-header-end">

    <?php settings_errors( 'amcp_messages' ); ?>

    <form method="post" action="">
        <input type="hidden" name="amcp_action" value="save_settings">
        <?php wp_nonce_field( 'amcp_save_settings', 'amcp_nonce' ); ?>

        <table class="form-table">
            <tr>
                <th scope="row">Status do Plugin</th>
                <td>
                    <label>
                        <input type="checkbox" name="amcp_enabled" value="1" <?php checked( $enabled, '1' ); ?>>
                        Plugin ativo
                    </label>
                    <p class="description">Quando desativado, todas as requisições à API REST serão rejeitadas com status 503.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Endpoint da API REST</th>
                <td>
                    <code class="amcp-endpoint-display"><?php echo esc_html( $rest_endpoint ); ?></code>
                    <p class="description">URL base para requisições dos agentes AI. Somente leitura.</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="amcp_log_retention">Retenção de Registros</label></th>
                <td>
                    <select id="amcp_log_retention" name="amcp_log_retention">
                        <option value="7" <?php selected( $log_retention, '7' ); ?>>7 dias</option>
                        <option value="30" <?php selected( $log_retention, '30' ); ?>>30 dias</option>
                        <option value="90" <?php selected( $log_retention, '90' ); ?>>90 dias</option>
                        <option value="0" <?php selected( $log_retention, '0' ); ?>>Nunca deletar</option>
                    </select>
                    <p class="description">Registros mais antigos que o período selecionado serão removidos automaticamente.</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="amcp_rate_limit">Limite de Requisições</label></th>
                <td>
                    <input type="number" id="amcp_rate_limit" name="amcp_rate_limit"
                           value="<?php echo esc_attr( $rate_limit ); ?>"
                           min="1" max="10000" class="small-text">
                    <span>requisições por minuto por chave</span>
                    <p class="description">Número máximo de chamadas à API por minuto para cada chave API.</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="amcp_protected_paths">Caminhos Protegidos</label></th>
                <td>
                    <textarea id="amcp_protected_paths" name="amcp_protected_paths"
                              rows="6" class="large-text code"><?php echo esc_textarea( $protected_text ); ?></textarea>
                    <p class="description">Um caminho por linha. Arquivos e diretórios listados aqui não poderão ser acessados pela API (leitura, escrita, exclusão).</p>
                </td>
            </tr>
        </table>

        <p class="submit">
            <button type="submit" class="button button-primary">Salvar Configurações</button>
        </p>
    </form>

    <!-- Zona de Perigo -->
    <div class="amcp-danger-zone">
        <h2>Zona de Perigo</h2>
        <p>Ações destrutivas e irreversíveis. Proceda com cautela.</p>

        <div class="amcp-danger-actions">
            <div class="amcp-danger-action">
                <div class="amcp-danger-action-info">
                    <h4>Revogar Todas as Chaves</h4>
                    <p>Todas as chaves API ativas serão revogadas imediatamente. Os agentes AI perderão acesso ao site.</p>
                </div>
                <form method="post" action="">
                    <input type="hidden" name="amcp_action" value="revoke_all_keys">
                    <?php wp_nonce_field( 'amcp_danger_zone', 'amcp_nonce' ); ?>
                    <button type="submit" class="button amcp-danger-button amcp-confirm-revoke-all">
                        Revogar Todas as Chaves
                    </button>
                </form>
            </div>

            <div class="amcp-danger-action">
                <div class="amcp-danger-action-info">
                    <h4>Limpar Todos os Registros</h4>
                    <p>Todos os registros de atividade serão permanentemente removidos. Esta ação não pode ser desfeita.</p>
                </div>
                <form method="post" action="">
                    <input type="hidden" name="amcp_action" value="clear_all_logs">
                    <?php wp_nonce_field( 'amcp_danger_zone', 'amcp_nonce' ); ?>
                    <button type="submit" class="button amcp-danger-button amcp-confirm-clear-logs">
                        Limpar Todos os Registros
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
