/**
 * Automation MCP - Admin JavaScript
 *
 * @package AutomationMCP
 * @author  alissondsgn
 */

(function ($) {
    'use strict';

    $(document).ready(function () {

        // ============================================
        // Toggle formulário inline - Nova Chave API
        // ============================================

        var $newKeyForm = $('#amcp-new-key-form');
        var $toggleBtn = $('#amcp-toggle-new-key');

        $toggleBtn.on('click', function () {
            $newKeyForm.slideToggle(200);
            if ($newKeyForm.is(':visible')) {
                $newKeyForm.find('input[type="text"]').first().focus();
            }
        });

        $('.amcp-cancel-new-key').on('click', function () {
            $newKeyForm.slideUp(200);
        });

        // ============================================
        // Copiar chave para área de transferência
        // ============================================

        $('.amcp-copy-key').on('click', function () {
            var $btn = $(this);
            var targetId = $btn.data('target');
            var $target = $('#' + targetId);
            var text = $target.text().trim();

            if (!text) {
                return;
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function () {
                    showCopyFeedback($btn);
                }).catch(function () {
                    fallbackCopy(text, $btn);
                });
            } else {
                fallbackCopy(text, $btn);
            }
        });

        function fallbackCopy(text, $btn) {
            var $temp = $('<textarea>');
            $temp.val(text).css({
                position: 'fixed',
                left: '-9999px',
                top: '0'
            }).appendTo('body');
            $temp[0].select();
            try {
                document.execCommand('copy');
                showCopyFeedback($btn);
            } catch (e) {
                alert('Não foi possível copiar. Selecione a chave manualmente.');
            }
            $temp.remove();
        }

        function showCopyFeedback($btn) {
            var originalText = $btn.text();
            $btn.text('Copiado!').prop('disabled', true);
            setTimeout(function () {
                $btn.text(originalText).prop('disabled', false);
            }, 2000);
        }

        // ============================================
        // Confirmação para revogar chave individual
        // ============================================

        $('.amcp-confirm-revoke').on('click', function (e) {
            var name = $(this).data('name') || 'esta chave';
            var msg = 'Tem certeza que deseja revogar a chave "' + name + '"?\n\nEsta ação não pode ser desfeita. O cliente perderá acesso imediatamente.';
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });

        // ============================================
        // Confirmação - Revogar todas as chaves
        // ============================================

        $('.amcp-confirm-revoke-all').on('click', function (e) {
            var msg = 'ATENÇÃO: Você está prestes a revogar TODAS as chaves API ativas.\n\nTodos os agentes AI perderão acesso ao site imediatamente.\n\nDeseja continuar?';
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });

        // ============================================
        // Confirmação - Limpar todos os registros
        // ============================================

        $('.amcp-confirm-clear-logs').on('click', function (e) {
            var msg = 'ATENÇÃO: Você está prestes a remover TODOS os registros de atividade.\n\nEsta ação é permanente e não pode ser desfeita.\n\nDeseja continuar?';
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });

        // ============================================
        // Auto-submit ao trocar chave no dropdown
        // (página de habilidades)
        // ============================================

        $('#amcp-key-selector').on('change', function () {
            $('#amcp-key-selector-form').submit();
        });

        // ============================================
        // Selecionar todas as habilidades de uma categoria
        // ============================================

        $('.amcp-select-all-cat').on('change', function () {
            var category = $(this).data('category');
            var isChecked = $(this).is(':checked');
            $('[data-category="' + category + '"] input[type="checkbox"][name="abilities[]"]').prop('checked', isChecked);
        });

        // Atualizar checkbox "selecionar tudo" quando itens individuais mudam
        $('input[name="abilities[]"]').on('change', function () {
            var $item = $(this).closest('[data-category]');
            var category = $item.data('category');
            var $allInCat = $('[data-category="' + category + '"] input[name="abilities[]"]');
            var $checkedInCat = $allInCat.filter(':checked');
            var $selectAll = $('.amcp-select-all-cat[data-category="' + category + '"]');
            $selectAll.prop('checked', $allInCat.length === $checkedInCat.length);
            $selectAll.prop('indeterminate', $checkedInCat.length > 0 && $checkedInCat.length < $allInCat.length);
        });

        // Inicializar estado dos checkboxes "selecionar tudo" ao carregar
        $('.amcp-select-all-cat').each(function () {
            var category = $(this).data('category');
            var $allInCat = $('[data-category="' + category + '"] input[name="abilities[]"]');
            var $checkedInCat = $allInCat.filter(':checked');
            if ($allInCat.length > 0) {
                $(this).prop('checked', $allInCat.length === $checkedInCat.length);
                $(this).prop('indeterminate', $checkedInCat.length > 0 && $checkedInCat.length < $allInCat.length);
            }
        });

    });

})(jQuery);
