<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AMCP_Installer {

    public static function activate() {
        self::create_tables();
        self::set_default_options();
    }

    public static function deactivate() {
        // Keep data on deactivation — only clean on uninstall
    }

    private static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $keys_table = $wpdb->prefix . 'amcp_api_keys';
        $logs_table = $wpdb->prefix . 'amcp_logs';

        $sql_keys = "CREATE TABLE $keys_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            key_hash varchar(64) NOT NULL,
            key_prefix varchar(12) NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            abilities longtext NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'active',
            last_used_at datetime DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY key_hash (key_hash),
            KEY user_id (user_id),
            KEY status (status)
        ) $charset;";

        $sql_logs = "CREATE TABLE $logs_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            api_key_id bigint(20) unsigned NOT NULL,
            action varchar(100) NOT NULL,
            params longtext DEFAULT NULL,
            result_status varchar(20) NOT NULL DEFAULT 'success',
            result_message text DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY api_key_id (api_key_id),
            KEY action (action),
            KEY result_status (result_status),
            KEY created_at (created_at)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql_keys );
        dbDelta( $sql_logs );
    }

    private static function set_default_options() {
        add_option( 'amcp_enabled', '1' );
        add_option( 'amcp_log_retention', '30' );
        add_option( 'amcp_rate_limit', '100' );
        add_option( 'amcp_protected_paths', wp_json_encode( array(
            'wp-admin/',
            'wp-includes/',
            '.htaccess',
            'wp-config.php',
        )));
    }
}
