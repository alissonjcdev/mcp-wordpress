<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AMCP_Actions — Manipulador de ações do plugin Automation MCP.
 *
 * Converte nomes de ação (ex.: "create-post") em métodos internos (ex.: "create_post")
 * e os executa, retornando sempre um array com chave 'data' e opcional 'message'.
 */
class AMCP_Actions {

	/* =========================================================================
	 * DISPATCHER
	 * ====================================================================== */

	/**
	 * Executa uma ação registrada.
	 *
	 * @param string $action Nome da ação (ex.: "create-post").
	 * @param array  $params Parâmetros da ação.
	 * @return array ['data' => mixed, 'message' => string]
	 * @throws RuntimeException Quando a ação não existe ou ocorre erro.
	 */
	public static function execute( string $action, array $params ): array {

		$method = str_replace( '-', '_', sanitize_text_field( $action ) );

		if ( ! method_exists( static::class, $method ) ) {
			throw new RuntimeException(
				sprintf( 'Ação "%s" não encontrada.', esc_html( $action ) )
			);
		}

		return static::$method( $params );
	}

	/* =========================================================================
	 * HELPERS
	 * ====================================================================== */

	/**
	 * Verifica se um caminho está protegido contra escrita/exclusão.
	 *
	 * @param string $path Caminho absoluto a verificar.
	 * @throws RuntimeException Quando o caminho está protegido.
	 */
	private static function check_protected_path( string $path ): void {

		$real = realpath( $path );
		if ( false === $real ) {
			$real = $path; // Arquivo ainda não existe — verificar pelo caminho informado.
		}

		$protected = get_option( 'amcp_protected_paths', array() );
		if ( ! is_array( $protected ) ) {
			$protected = array();
		}

		foreach ( $protected as $pp ) {
			$pp = rtrim( $pp, '/' );
			if ( 0 === strpos( $real, $pp ) ) {
				throw new RuntimeException(
					sprintf( 'O caminho "%s" está protegido e não pode ser modificado.', esc_html( $path ) )
				);
			}
		}
	}

	/**
	 * Remove recursivamente um diretório e todo o seu conteúdo.
	 *
	 * @param string $dir Caminho absoluto do diretório.
	 * @return bool
	 */
	private static function rmdir_recursive( string $dir ): bool {

		if ( ! is_dir( $dir ) ) {
			return false;
		}

		$items = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			if ( $item->isDir() ) {
				rmdir( $item->getRealPath() );
			} else {
				unlink( $item->getRealPath() );
			}
		}

		return rmdir( $dir );
	}

	/* =========================================================================
	 * CONTENT MANAGEMENT (8)
	 * ====================================================================== */

	/**
	 * 1. create_post — Cria um novo post/CPT.
	 */
	private static function create_post( array $params ): array {

		$post_data = array(
			'post_title'   => sanitize_text_field( $params['title'] ?? '' ),
			'post_content' => wp_kses_post( $params['content'] ?? '' ),
			'post_status'  => sanitize_text_field( $params['status'] ?? 'draft' ),
			'post_type'    => sanitize_text_field( $params['type'] ?? 'post' ),
			'post_excerpt' => sanitize_text_field( $params['excerpt'] ?? '' ),
		);

		if ( ! empty( $params['author'] ) ) {
			$post_data['post_author'] = absint( $params['author'] );
		}

		if ( ! empty( $params['slug'] ) ) {
			$post_data['post_name'] = sanitize_title( $params['slug'] );
		}

		$post_id = wp_insert_post( $post_data, true );

		if ( is_wp_error( $post_id ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao criar post: %s', $post_id->get_error_message() )
			);
		}

		// Imagem destacada.
		if ( ! empty( $params['featured_image'] ) ) {
			$attachment_id = absint( $params['featured_image'] );
			if ( $attachment_id ) {
				set_post_thumbnail( $post_id, $attachment_id );
			}
		}

		// Categorias.
		if ( ! empty( $params['categories'] ) && is_array( $params['categories'] ) ) {
			wp_set_post_categories( $post_id, array_map( 'absint', $params['categories'] ) );
		}

		// Tags.
		if ( ! empty( $params['tags'] ) && is_array( $params['tags'] ) ) {
			wp_set_post_tags( $post_id, array_map( 'sanitize_text_field', $params['tags'] ) );
		}

		return array(
			'data'    => array( 'post_id' => $post_id ),
			'message' => 'Post criado com sucesso.',
		);
	}

	/**
	 * 2. update_post — Atualiza um post existente.
	 */
	private static function update_post( array $params ): array {

		if ( empty( $params['post_id'] ) ) {
			throw new RuntimeException( 'O parâmetro "post_id" é obrigatório.' );
		}

		$post_id = absint( $params['post_id'] );

		$existing = get_post( $post_id );
		if ( ! $existing ) {
			throw new RuntimeException( sprintf( 'Post #%d não encontrado.', $post_id ) );
		}

		$post_data = array( 'ID' => $post_id );

		if ( isset( $params['title'] ) ) {
			$post_data['post_title'] = sanitize_text_field( $params['title'] );
		}
		if ( isset( $params['content'] ) ) {
			$post_data['post_content'] = wp_kses_post( $params['content'] );
		}
		if ( isset( $params['status'] ) ) {
			$post_data['post_status'] = sanitize_text_field( $params['status'] );
		}
		if ( isset( $params['type'] ) ) {
			$post_data['post_type'] = sanitize_text_field( $params['type'] );
		}
		if ( isset( $params['excerpt'] ) ) {
			$post_data['post_excerpt'] = sanitize_text_field( $params['excerpt'] );
		}
		if ( isset( $params['author'] ) ) {
			$post_data['post_author'] = absint( $params['author'] );
		}
		if ( isset( $params['slug'] ) ) {
			$post_data['post_name'] = sanitize_title( $params['slug'] );
		}

		$result = wp_update_post( $post_data, true );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao atualizar post: %s', $result->get_error_message() )
			);
		}

		if ( isset( $params['featured_image'] ) ) {
			$attachment_id = absint( $params['featured_image'] );
			if ( $attachment_id ) {
				set_post_thumbnail( $post_id, $attachment_id );
			} else {
				delete_post_thumbnail( $post_id );
			}
		}

		if ( isset( $params['categories'] ) && is_array( $params['categories'] ) ) {
			wp_set_post_categories( $post_id, array_map( 'absint', $params['categories'] ) );
		}

		if ( isset( $params['tags'] ) && is_array( $params['tags'] ) ) {
			wp_set_post_tags( $post_id, array_map( 'sanitize_text_field', $params['tags'] ) );
		}

		return array(
			'data'    => array( 'post_id' => $post_id ),
			'message' => 'Post atualizado com sucesso.',
		);
	}

	/**
	 * 3. delete_post — Exclui um post (lixeira ou permanente).
	 */
	private static function delete_post( array $params ): array {

		if ( empty( $params['post_id'] ) ) {
			throw new RuntimeException( 'O parâmetro "post_id" é obrigatório.' );
		}

		$post_id = absint( $params['post_id'] );
		$force   = ! empty( $params['force'] );

		$existing = get_post( $post_id );
		if ( ! $existing ) {
			throw new RuntimeException( sprintf( 'Post #%d não encontrado.', $post_id ) );
		}

		$result = wp_delete_post( $post_id, $force );

		if ( false === $result || null === $result ) {
			throw new RuntimeException( sprintf( 'Não foi possível excluir o post #%d.', $post_id ) );
		}

		return array(
			'data'    => array( 'post_id' => $post_id, 'force' => $force ),
			'message' => $force ? 'Post excluído permanentemente.' : 'Post movido para a lixeira.',
		);
	}

	/**
	 * 4. list_posts — Lista posts com filtros via WP_Query.
	 */
	private static function list_posts( array $params ): array {

		$args = array(
			'post_type'      => sanitize_text_field( $params['type'] ?? 'post' ),
			'post_status'    => sanitize_text_field( $params['status'] ?? 'any' ),
			'posts_per_page' => absint( $params['per_page'] ?? 10 ),
			'paged'          => absint( $params['page'] ?? 1 ),
			'orderby'        => sanitize_text_field( $params['orderby'] ?? 'date' ),
			'order'          => sanitize_text_field( $params['order'] ?? 'DESC' ),
		);

		if ( ! empty( $params['search'] ) ) {
			$args['s'] = sanitize_text_field( $params['search'] );
		}

		if ( ! empty( $params['category'] ) ) {
			$args['cat'] = absint( $params['category'] );
		}

		if ( ! empty( $params['author'] ) ) {
			$args['author'] = absint( $params['author'] );
		}

		$query = new WP_Query( $args );
		$posts = array();

		foreach ( $query->posts as $p ) {
			$posts[] = array(
				'ID'         => $p->ID,
				'title'      => $p->post_title,
				'slug'       => $p->post_name,
				'status'     => $p->post_status,
				'type'       => $p->post_type,
				'date'       => $p->post_date,
				'modified'   => $p->post_modified,
				'author'     => (int) $p->post_author,
				'excerpt'    => $p->post_excerpt,
				'permalink'  => get_permalink( $p->ID ),
			);
		}

		return array(
			'data' => array(
				'posts'       => $posts,
				'total'       => (int) $query->found_posts,
				'total_pages' => (int) $query->max_num_pages,
				'page'        => absint( $params['page'] ?? 1 ),
			),
		);
	}

	/**
	 * 5. get_post — Retorna dados completos de um post.
	 */
	private static function get_post( array $params ): array {

		if ( empty( $params['post_id'] ) ) {
			throw new RuntimeException( 'O parâmetro "post_id" é obrigatório.' );
		}

		$post_id = absint( $params['post_id'] );
		$post    = get_post( $post_id );

		if ( ! $post ) {
			throw new RuntimeException( sprintf( 'Post #%d não encontrado.', $post_id ) );
		}

		$meta       = get_post_meta( $post_id );
		$categories = wp_get_post_categories( $post_id, array( 'fields' => 'all' ) );
		$tags       = wp_get_post_tags( $post_id, array( 'fields' => 'all' ) );

		$featured_image_id  = get_post_thumbnail_id( $post_id );
		$featured_image_url = $featured_image_id ? wp_get_attachment_url( $featured_image_id ) : null;

		$cat_data = array();
		if ( is_array( $categories ) ) {
			foreach ( $categories as $cat ) {
				$cat_data[] = array(
					'term_id' => $cat->term_id,
					'name'    => $cat->name,
					'slug'    => $cat->slug,
				);
			}
		}

		$tag_data = array();
		if ( is_array( $tags ) ) {
			foreach ( $tags as $tag ) {
				$tag_data[] = array(
					'term_id' => $tag->term_id,
					'name'    => $tag->name,
					'slug'    => $tag->slug,
				);
			}
		}

		return array(
			'data' => array(
				'ID'             => $post->ID,
				'title'          => $post->post_title,
				'content'        => $post->post_content,
				'excerpt'        => $post->post_excerpt,
				'slug'           => $post->post_name,
				'status'         => $post->post_status,
				'type'           => $post->post_type,
				'date'           => $post->post_date,
				'modified'       => $post->post_modified,
				'author'         => (int) $post->post_author,
				'permalink'      => get_permalink( $post_id ),
				'featured_image' => array(
					'id'  => $featured_image_id ? (int) $featured_image_id : null,
					'url' => $featured_image_url,
				),
				'categories'     => $cat_data,
				'tags'           => $tag_data,
				'meta'           => $meta,
			),
		);
	}

	/**
	 * 6. manage_taxonomies — CRUD para qualquer taxonomia.
	 *
	 * $params['operation']: list | create | update | delete
	 * $params['taxonomy']:  ex.: "category", "post_tag", custom…
	 */
	private static function manage_taxonomies( array $params ): array {

		$operation = sanitize_text_field( $params['operation'] ?? 'list' );
		$taxonomy  = sanitize_text_field( $params['taxonomy'] ?? 'category' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			throw new RuntimeException( sprintf( 'Taxonomia "%s" não existe.', esc_html( $taxonomy ) ) );
		}

		switch ( $operation ) {

			case 'list':
				$args = array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => ! empty( $params['hide_empty'] ),
					'number'     => absint( $params['per_page'] ?? 0 ),
					'offset'     => absint( $params['offset'] ?? 0 ),
				);

				if ( ! empty( $params['search'] ) ) {
					$args['search'] = sanitize_text_field( $params['search'] );
				}

				$terms   = get_terms( $args );
				$results = array();

				if ( is_wp_error( $terms ) ) {
					throw new RuntimeException( $terms->get_error_message() );
				}

				foreach ( $terms as $term ) {
					$results[] = array(
						'term_id'     => $term->term_id,
						'name'        => $term->name,
						'slug'        => $term->slug,
						'description' => $term->description,
						'parent'      => $term->parent,
						'count'       => $term->count,
					);
				}

				return array( 'data' => $results );

			case 'create':
				if ( empty( $params['name'] ) ) {
					throw new RuntimeException( 'O parâmetro "name" é obrigatório para criar um termo.' );
				}

				$term_args = array();
				if ( ! empty( $params['slug'] ) ) {
					$term_args['slug'] = sanitize_title( $params['slug'] );
				}
				if ( ! empty( $params['description'] ) ) {
					$term_args['description'] = sanitize_text_field( $params['description'] );
				}
				if ( ! empty( $params['parent'] ) ) {
					$term_args['parent'] = absint( $params['parent'] );
				}

				$result = wp_insert_term(
					sanitize_text_field( $params['name'] ),
					$taxonomy,
					$term_args
				);

				if ( is_wp_error( $result ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao criar termo: %s', $result->get_error_message() )
					);
				}

				return array(
					'data'    => array( 'term_id' => $result['term_id'] ),
					'message' => 'Termo criado com sucesso.',
				);

			case 'update':
				if ( empty( $params['term_id'] ) ) {
					throw new RuntimeException( 'O parâmetro "term_id" é obrigatório para atualizar um termo.' );
				}

				$term_id   = absint( $params['term_id'] );
				$term_args = array();

				if ( isset( $params['name'] ) ) {
					$term_args['name'] = sanitize_text_field( $params['name'] );
				}
				if ( isset( $params['slug'] ) ) {
					$term_args['slug'] = sanitize_title( $params['slug'] );
				}
				if ( isset( $params['description'] ) ) {
					$term_args['description'] = sanitize_text_field( $params['description'] );
				}
				if ( isset( $params['parent'] ) ) {
					$term_args['parent'] = absint( $params['parent'] );
				}

				$result = wp_update_term( $term_id, $taxonomy, $term_args );

				if ( is_wp_error( $result ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao atualizar termo: %s', $result->get_error_message() )
					);
				}

				return array(
					'data'    => array( 'term_id' => $term_id ),
					'message' => 'Termo atualizado com sucesso.',
				);

			case 'delete':
				if ( empty( $params['term_id'] ) ) {
					throw new RuntimeException( 'O parâmetro "term_id" é obrigatório para excluir um termo.' );
				}

				$term_id = absint( $params['term_id'] );
				$result  = wp_delete_term( $term_id, $taxonomy );

				if ( is_wp_error( $result ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao excluir termo: %s', $result->get_error_message() )
					);
				}

				if ( false === $result ) {
					throw new RuntimeException( 'Não foi possível excluir o termo (é o padrão da taxonomia?).' );
				}

				return array(
					'data'    => array( 'term_id' => $term_id ),
					'message' => 'Termo excluído com sucesso.',
				);

			default:
				throw new RuntimeException(
					sprintf( 'Operação "%s" inválida para manage_taxonomies. Use: list, create, update, delete.', esc_html( $operation ) )
				);
		}
	}

	/**
	 * 7. manage_seo — Lê/escreve campos de SEO (Yoast e RankMath).
	 *
	 * $params['operation']: get | set
	 * $params['post_id']:   ID do post
	 * $params['plugin']:    yoast | rankmath (auto-detecta se omitido)
	 * $params['fields']:    array de campos a ler ou array key=>value a gravar
	 */
	private static function manage_seo( array $params ): array {

		if ( empty( $params['post_id'] ) ) {
			throw new RuntimeException( 'O parâmetro "post_id" é obrigatório.' );
		}

		$post_id   = absint( $params['post_id'] );
		$operation = sanitize_text_field( $params['operation'] ?? 'get' );

		// Auto-detectar plugin SEO.
		$plugin = sanitize_text_field( $params['plugin'] ?? '' );
		if ( '' === $plugin ) {
			if ( defined( 'WPSEO_VERSION' ) ) {
				$plugin = 'yoast';
			} elseif ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
				$plugin = 'rankmath';
			} else {
				$plugin = 'yoast'; // fallback
			}
		}

		$prefix = 'yoast' === $plugin ? '_yoast_wpseo_' : 'rank_math_';

		$known_fields = array(
			'yoast'    => array(
				'title', 'metadesc', 'focuskw', 'canonical', 'opengraph-title',
				'opengraph-description', 'opengraph-image', 'twitter-title',
				'twitter-description', 'twitter-image', 'meta-robots-noindex',
				'meta-robots-nofollow', 'schema_page_type', 'schema_article_type',
			),
			'rankmath' => array(
				'title', 'description', 'focus_keyword', 'canonical_url',
				'facebook_title', 'facebook_description', 'facebook_image',
				'twitter_title', 'twitter_description', 'twitter_image',
				'robots', 'schema_Article',
			),
		);

		switch ( $operation ) {

			case 'get':
				$fields_to_read = $params['fields'] ?? $known_fields[ $plugin ] ?? array();

				if ( ! is_array( $fields_to_read ) ) {
					$fields_to_read = array( $fields_to_read );
				}

				$data = array();
				foreach ( $fields_to_read as $field ) {
					$meta_key        = $prefix . sanitize_text_field( $field );
					$data[ $field ]  = get_post_meta( $post_id, $meta_key, true );
				}

				return array(
					'data' => array(
						'post_id' => $post_id,
						'plugin'  => $plugin,
						'fields'  => $data,
					),
				);

			case 'set':
				if ( empty( $params['fields'] ) || ! is_array( $params['fields'] ) ) {
					throw new RuntimeException( 'O parâmetro "fields" deve ser um array key=>value para gravação.' );
				}

				$updated = array();
				foreach ( $params['fields'] as $field => $value ) {
					$meta_key = $prefix . sanitize_text_field( $field );
					update_post_meta( $post_id, $meta_key, sanitize_text_field( $value ) );
					$updated[] = $field;
				}

				return array(
					'data'    => array(
						'post_id' => $post_id,
						'plugin'  => $plugin,
						'updated' => $updated,
					),
					'message' => 'Campos de SEO atualizados com sucesso.',
				);

			default:
				throw new RuntimeException(
					sprintf( 'Operação "%s" inválida para manage_seo. Use: get, set.', esc_html( $operation ) )
				);
		}
	}

	/**
	 * 8. manage_post_meta — Get/set/delete meta genérico de post.
	 *
	 * $params['operation']: get | set | delete
	 * $params['post_id']:   ID do post
	 * $params['meta_key']:  chave do meta
	 * $params['meta_value']: valor (para set)
	 */
	private static function manage_post_meta( array $params ): array {

		if ( empty( $params['post_id'] ) ) {
			throw new RuntimeException( 'O parâmetro "post_id" é obrigatório.' );
		}

		$post_id   = absint( $params['post_id'] );
		$operation = sanitize_text_field( $params['operation'] ?? 'get' );

		if ( ! get_post( $post_id ) ) {
			throw new RuntimeException( sprintf( 'Post #%d não encontrado.', $post_id ) );
		}

		switch ( $operation ) {

			case 'get':
				if ( ! empty( $params['meta_key'] ) ) {
					$meta_key = sanitize_text_field( $params['meta_key'] );
					$value    = get_post_meta( $post_id, $meta_key, true );

					return array(
						'data' => array(
							'post_id'  => $post_id,
							'meta_key' => $meta_key,
							'value'    => $value,
						),
					);
				}

				// Retornar todos os metas.
				return array(
					'data' => array(
						'post_id' => $post_id,
						'meta'    => get_post_meta( $post_id ),
					),
				);

			case 'set':
				if ( empty( $params['meta_key'] ) ) {
					throw new RuntimeException( 'O parâmetro "meta_key" é obrigatório para set.' );
				}

				$meta_key   = sanitize_text_field( $params['meta_key'] );
				$meta_value = $params['meta_value'] ?? '';

				update_post_meta( $post_id, $meta_key, $meta_value );

				return array(
					'data'    => array(
						'post_id'  => $post_id,
						'meta_key' => $meta_key,
					),
					'message' => 'Meta atualizado com sucesso.',
				);

			case 'delete':
				if ( empty( $params['meta_key'] ) ) {
					throw new RuntimeException( 'O parâmetro "meta_key" é obrigatório para delete.' );
				}

				$meta_key = sanitize_text_field( $params['meta_key'] );
				delete_post_meta( $post_id, $meta_key );

				return array(
					'data'    => array(
						'post_id'  => $post_id,
						'meta_key' => $meta_key,
					),
					'message' => 'Meta excluído com sucesso.',
				);

			default:
				throw new RuntimeException(
					sprintf( 'Operação "%s" inválida para manage_post_meta. Use: get, set, delete.', esc_html( $operation ) )
				);
		}
	}

	/* =========================================================================
	 * THEMES (4)
	 * ====================================================================== */

	/**
	 * 9. list_themes — Lista temas instalados.
	 */
	private static function list_themes( array $params ): array {

		$themes      = wp_get_themes();
		$active_slug = get_stylesheet();
		$data        = array();

		foreach ( $themes as $slug => $theme ) {
			$data[] = array(
				'slug'        => $slug,
				'name'        => $theme->get( 'Name' ),
				'version'     => $theme->get( 'Version' ),
				'author'      => $theme->get( 'Author' ),
				'description' => $theme->get( 'Description' ),
				'active'      => ( $slug === $active_slug ),
				'template'    => $theme->get_template(),
				'screenshot'  => $theme->get_screenshot(),
			);
		}

		return array( 'data' => $data );
	}

	/**
	 * 10. install_theme — Instala um tema do repositório WP.
	 */
	private static function install_theme( array $params ): array {

		if ( empty( $params['slug'] ) ) {
			throw new RuntimeException( 'O parâmetro "slug" é obrigatório.' );
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/theme.php';

		$slug = sanitize_text_field( $params['slug'] );

		$api = themes_api( 'theme_information', array(
			'slug'   => $slug,
			'fields' => array( 'sections' => false ),
		) );

		if ( is_wp_error( $api ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao buscar tema "%s": %s', esc_html( $slug ), $api->get_error_message() )
			);
		}

		$upgrader = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
		$result   = $upgrader->install( $api->download_link );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao instalar tema: %s', $result->get_error_message() )
			);
		}

		if ( false === $result ) {
			throw new RuntimeException( 'Não foi possível instalar o tema.' );
		}

		$activate = ! empty( $params['activate'] );
		if ( $activate ) {
			switch_theme( $slug );
		}

		return array(
			'data'    => array( 'slug' => $slug, 'activated' => $activate ),
			'message' => 'Tema instalado com sucesso.',
		);
	}

	/**
	 * 11. activate_theme — Ativa um tema instalado.
	 */
	private static function activate_theme( array $params ): array {

		if ( empty( $params['slug'] ) ) {
			throw new RuntimeException( 'O parâmetro "slug" é obrigatório.' );
		}

		$slug = sanitize_text_field( $params['slug'] );
		$theme = wp_get_theme( $slug );

		if ( ! $theme->exists() ) {
			throw new RuntimeException( sprintf( 'Tema "%s" não está instalado.', esc_html( $slug ) ) );
		}

		switch_theme( $slug );

		return array(
			'data'    => array( 'slug' => $slug ),
			'message' => sprintf( 'Tema "%s" ativado com sucesso.', esc_html( $slug ) ),
		);
	}

	/**
	 * 12. customize_theme — Define configurações de tema (theme_mods).
	 */
	private static function customize_theme( array $params ): array {

		if ( empty( $params['settings'] ) || ! is_array( $params['settings'] ) ) {
			throw new RuntimeException( 'O parâmetro "settings" (array key=>value) é obrigatório.' );
		}

		$updated = array();

		foreach ( $params['settings'] as $key => $value ) {
			$key = sanitize_text_field( $key );
			set_theme_mod( $key, $value );
			$updated[] = $key;
		}

		return array(
			'data'    => array( 'updated' => $updated ),
			'message' => 'Configurações do tema atualizadas com sucesso.',
		);
	}

	/* =========================================================================
	 * PLUGINS (4)
	 * ====================================================================== */

	/**
	 * 13. list_plugins — Lista plugins instalados.
	 */
	private static function list_plugins( array $params ): array {

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins    = get_plugins();
		$active_plugins = get_option( 'active_plugins', array() );
		$data           = array();

		foreach ( $all_plugins as $file => $info ) {
			$data[] = array(
				'file'        => $file,
				'name'        => $info['Name'] ?? '',
				'version'     => $info['Version'] ?? '',
				'author'      => $info['Author'] ?? '',
				'description' => $info['Description'] ?? '',
				'active'      => in_array( $file, $active_plugins, true ),
				'url'         => $info['PluginURI'] ?? '',
			);
		}

		return array( 'data' => $data );
	}

	/**
	 * 14. install_plugin — Instala um plugin do repositório WP.
	 */
	private static function install_plugin( array $params ): array {

		if ( empty( $params['slug'] ) ) {
			throw new RuntimeException( 'O parâmetro "slug" é obrigatório.' );
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$slug = sanitize_text_field( $params['slug'] );

		$api = plugins_api( 'plugin_information', array(
			'slug'   => $slug,
			'fields' => array( 'sections' => false ),
		) );

		if ( is_wp_error( $api ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao buscar plugin "%s": %s', esc_html( $slug ), $api->get_error_message() )
			);
		}

		$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
		$result   = $upgrader->install( $api->download_link );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao instalar plugin: %s', $result->get_error_message() )
			);
		}

		if ( false === $result ) {
			throw new RuntimeException( 'Não foi possível instalar o plugin.' );
		}

		$activate = ! empty( $params['activate'] );
		if ( $activate ) {
			$plugin_file = $upgrader->plugin_info();
			if ( $plugin_file ) {
				$activation = activate_plugin( $plugin_file );
				if ( is_wp_error( $activation ) ) {
					throw new RuntimeException(
						sprintf( 'Plugin instalado, mas erro ao ativar: %s', $activation->get_error_message() )
					);
				}
			}
		}

		return array(
			'data'    => array( 'slug' => $slug, 'activated' => $activate ),
			'message' => 'Plugin instalado com sucesso.',
		);
	}

	/**
	 * 15. activate_plugin — Ativa ou desativa um plugin.
	 */
	private static function activate_plugin( array $params ): array {

		if ( empty( $params['plugin'] ) ) {
			throw new RuntimeException( 'O parâmetro "plugin" (arquivo relativo) é obrigatório.' );
		}

		if ( ! function_exists( 'activate_plugin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_file = sanitize_text_field( $params['plugin'] );
		$deactivate  = ! empty( $params['deactivate'] );

		if ( $deactivate ) {
			deactivate_plugins( $plugin_file );

			return array(
				'data'    => array( 'plugin' => $plugin_file, 'active' => false ),
				'message' => 'Plugin desativado com sucesso.',
			);
		}

		$result = activate_plugin( $plugin_file );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao ativar plugin: %s', $result->get_error_message() )
			);
		}

		return array(
			'data'    => array( 'plugin' => $plugin_file, 'active' => true ),
			'message' => 'Plugin ativado com sucesso.',
		);
	}

	/**
	 * 16. delete_plugin — Exclui um plugin.
	 */
	private static function delete_plugin( array $params ): array {

		if ( empty( $params['plugin'] ) ) {
			throw new RuntimeException( 'O parâmetro "plugin" (arquivo relativo) é obrigatório.' );
		}

		if ( ! function_exists( 'delete_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$plugin_file = sanitize_text_field( $params['plugin'] );

		// Desativar antes de excluir.
		deactivate_plugins( $plugin_file );

		$result = delete_plugins( array( $plugin_file ) );

		if ( is_wp_error( $result ) ) {
			throw new RuntimeException(
				sprintf( 'Erro ao excluir plugin: %s', $result->get_error_message() )
			);
		}

		if ( false === $result ) {
			throw new RuntimeException( 'Não foi possível excluir o plugin.' );
		}

		return array(
			'data'    => array( 'plugin' => $plugin_file ),
			'message' => 'Plugin excluído com sucesso.',
		);
	}

	/* =========================================================================
	 * MEDIA (4)
	 * ====================================================================== */

	/**
	 * 17. upload_media — Faz upload de mídia (base64 ou URL).
	 */
	private static function upload_media( array $params ): array {

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$filename = sanitize_file_name( $params['filename'] ?? 'upload' );

		// Dados do arquivo: base64 ou URL.
		if ( ! empty( $params['base64'] ) ) {

			$decoded = base64_decode( $params['base64'], true );
			if ( false === $decoded ) {
				throw new RuntimeException( 'Dados base64 inválidos.' );
			}

			$tmp = wp_tempnam( $filename );
			file_put_contents( $tmp, $decoded );

			$file_array = array(
				'name'     => $filename,
				'tmp_name' => $tmp,
			);

		} elseif ( ! empty( $params['url'] ) ) {

			$tmp = download_url( esc_url_raw( $params['url'] ) );

			if ( is_wp_error( $tmp ) ) {
				throw new RuntimeException(
					sprintf( 'Erro ao baixar arquivo: %s', $tmp->get_error_message() )
				);
			}

			$file_array = array(
				'name'     => $filename,
				'tmp_name' => $tmp,
			);

		} else {
			throw new RuntimeException( 'Informe "base64" ou "url" para o upload.' );
		}

		$parent_post_id = absint( $params['post_id'] ?? 0 );
		$attachment_id   = media_handle_sideload( $file_array, $parent_post_id );

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $file_array['tmp_name'] );
			throw new RuntimeException(
				sprintf( 'Erro ao processar upload: %s', $attachment_id->get_error_message() )
			);
		}

		// Título e alt text.
		if ( ! empty( $params['title'] ) ) {
			wp_update_post( array(
				'ID'         => $attachment_id,
				'post_title' => sanitize_text_field( $params['title'] ),
			) );
		}

		if ( ! empty( $params['alt_text'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $params['alt_text'] ) );
		}

		return array(
			'data' => array(
				'attachment_id' => $attachment_id,
				'url'           => wp_get_attachment_url( $attachment_id ),
			),
			'message' => 'Mídia enviada com sucesso.',
		);
	}

	/**
	 * 18. bulk_upload_media — Upload em lote.
	 *
	 * $params['items']: array de itens, cada um com os mesmos campos de upload_media.
	 */
	private static function bulk_upload_media( array $params ): array {

		if ( empty( $params['items'] ) || ! is_array( $params['items'] ) ) {
			throw new RuntimeException( 'O parâmetro "items" (array) é obrigatório.' );
		}

		$results = array();
		$errors  = array();

		foreach ( $params['items'] as $index => $item ) {
			try {
				$result    = static::upload_media( $item );
				$results[] = $result['data'];
			} catch ( RuntimeException $e ) {
				$errors[] = array(
					'index'   => $index,
					'message' => $e->getMessage(),
				);
			}
		}

		return array(
			'data' => array(
				'uploaded' => $results,
				'errors'   => $errors,
				'total'    => count( $params['items'] ),
				'success'  => count( $results ),
				'failed'   => count( $errors ),
			),
			'message' => sprintf( '%d de %d arquivos enviados com sucesso.', count( $results ), count( $params['items'] ) ),
		);
	}

	/**
	 * 19. list_media — Lista mídia (attachments).
	 */
	private static function list_media( array $params ): array {

		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => absint( $params['per_page'] ?? 20 ),
			'paged'          => absint( $params['page'] ?? 1 ),
			'orderby'        => sanitize_text_field( $params['orderby'] ?? 'date' ),
			'order'          => sanitize_text_field( $params['order'] ?? 'DESC' ),
		);

		if ( ! empty( $params['search'] ) ) {
			$args['s'] = sanitize_text_field( $params['search'] );
		}

		if ( ! empty( $params['mime_type'] ) ) {
			$args['post_mime_type'] = sanitize_text_field( $params['mime_type'] );
		}

		$query = new WP_Query( $args );
		$media = array();

		foreach ( $query->posts as $p ) {
			$media[] = array(
				'ID'        => $p->ID,
				'title'     => $p->post_title,
				'url'       => wp_get_attachment_url( $p->ID ),
				'mime_type' => $p->post_mime_type,
				'date'      => $p->post_date,
				'alt_text'  => get_post_meta( $p->ID, '_wp_attachment_image_alt', true ),
				'filesize'  => filesize( get_attached_file( $p->ID ) ) ?: null,
			);
		}

		return array(
			'data' => array(
				'media'       => $media,
				'total'       => (int) $query->found_posts,
				'total_pages' => (int) $query->max_num_pages,
				'page'        => absint( $params['page'] ?? 1 ),
			),
		);
	}

	/**
	 * 20. delete_media — Exclui um anexo.
	 */
	private static function delete_media( array $params ): array {

		if ( empty( $params['attachment_id'] ) ) {
			throw new RuntimeException( 'O parâmetro "attachment_id" é obrigatório.' );
		}

		$attachment_id = absint( $params['attachment_id'] );
		$force         = ! empty( $params['force'] );

		$attachment = get_post( $attachment_id );
		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			throw new RuntimeException( sprintf( 'Anexo #%d não encontrado.', $attachment_id ) );
		}

		$result = wp_delete_attachment( $attachment_id, $force );

		if ( false === $result || null === $result ) {
			throw new RuntimeException( sprintf( 'Não foi possível excluir o anexo #%d.', $attachment_id ) );
		}

		return array(
			'data'    => array( 'attachment_id' => $attachment_id ),
			'message' => 'Mídia excluída com sucesso.',
		);
	}

	/* =========================================================================
	 * SETTINGS (5)
	 * ====================================================================== */

	/**
	 * 21. get_options — Lê opções do WordPress.
	 */
	private static function get_options( array $params ): array {

		if ( empty( $params['keys'] ) || ! is_array( $params['keys'] ) ) {
			throw new RuntimeException( 'O parâmetro "keys" (array de nomes) é obrigatório.' );
		}

		$data = array();
		foreach ( $params['keys'] as $key ) {
			$key          = sanitize_text_field( $key );
			$data[ $key ] = get_option( $key );
		}

		return array( 'data' => $data );
	}

	/**
	 * 22. update_options — Atualiza opções do WordPress.
	 */
	private static function update_options( array $params ): array {

		if ( empty( $params['options'] ) || ! is_array( $params['options'] ) ) {
			throw new RuntimeException( 'O parâmetro "options" (array key=>value) é obrigatório.' );
		}

		$updated = array();
		foreach ( $params['options'] as $key => $value ) {
			$key = sanitize_text_field( $key );
			update_option( $key, $value );
			$updated[] = $key;
		}

		return array(
			'data'    => array( 'updated' => $updated ),
			'message' => 'Opções atualizadas com sucesso.',
		);
	}

	/**
	 * 23. manage_menus — CRUD para menus de navegação.
	 *
	 * $params['operation']: list | create | add_item | delete
	 */
	private static function manage_menus( array $params ): array {

		$operation = sanitize_text_field( $params['operation'] ?? 'list' );

		switch ( $operation ) {

			case 'list':
				$menus = wp_get_nav_menus();
				$data  = array();

				foreach ( $menus as $menu ) {
					$items     = wp_get_nav_menu_items( $menu->term_id );
					$data[]    = array(
						'term_id'     => $menu->term_id,
						'name'        => $menu->name,
						'slug'        => $menu->slug,
						'description' => $menu->description,
						'count'       => $menu->count,
						'items'       => $items ? array_map( function ( $item ) {
							return array(
								'ID'        => $item->ID,
								'title'     => $item->title,
								'url'       => $item->url,
								'type'      => $item->type,
								'object'    => $item->object,
								'object_id' => (int) $item->object_id,
								'parent'    => (int) $item->menu_item_parent,
								'order'     => (int) $item->menu_order,
							);
						}, $items ) : array(),
					);
				}

				return array( 'data' => $data );

			case 'create':
				if ( empty( $params['name'] ) ) {
					throw new RuntimeException( 'O parâmetro "name" é obrigatório para criar um menu.' );
				}

				$menu_id = wp_create_nav_menu( sanitize_text_field( $params['name'] ) );

				if ( is_wp_error( $menu_id ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao criar menu: %s', $menu_id->get_error_message() )
					);
				}

				// Atribuir a uma localização do tema.
				if ( ! empty( $params['location'] ) ) {
					$locations                                                = get_theme_mod( 'nav_menu_locations', array() );
					$locations[ sanitize_text_field( $params['location'] ) ]  = $menu_id;
					set_theme_mod( 'nav_menu_locations', $locations );
				}

				return array(
					'data'    => array( 'menu_id' => $menu_id ),
					'message' => 'Menu criado com sucesso.',
				);

			case 'add_item':
				if ( empty( $params['menu_id'] ) ) {
					throw new RuntimeException( 'O parâmetro "menu_id" é obrigatório.' );
				}

				$menu_id   = absint( $params['menu_id'] );
				$item_data = array(
					'menu-item-title'     => sanitize_text_field( $params['title'] ?? '' ),
					'menu-item-url'       => esc_url_raw( $params['url'] ?? '' ),
					'menu-item-status'    => 'publish',
					'menu-item-type'      => sanitize_text_field( $params['type'] ?? 'custom' ),
					'menu-item-object'    => sanitize_text_field( $params['object'] ?? '' ),
					'menu-item-object-id' => absint( $params['object_id'] ?? 0 ),
					'menu-item-parent-id' => absint( $params['parent_id'] ?? 0 ),
					'menu-item-position'  => absint( $params['position'] ?? 0 ),
				);

				$item_id = wp_update_nav_menu_item( $menu_id, 0, $item_data );

				if ( is_wp_error( $item_id ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao adicionar item ao menu: %s', $item_id->get_error_message() )
					);
				}

				return array(
					'data'    => array( 'menu_id' => $menu_id, 'item_id' => $item_id ),
					'message' => 'Item adicionado ao menu com sucesso.',
				);

			case 'delete':
				if ( empty( $params['menu_id'] ) ) {
					throw new RuntimeException( 'O parâmetro "menu_id" é obrigatório.' );
				}

				$menu_id = absint( $params['menu_id'] );
				$result  = wp_delete_nav_menu( $menu_id );

				if ( is_wp_error( $result ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao excluir menu: %s', $result->get_error_message() )
					);
				}

				if ( false === $result ) {
					throw new RuntimeException( 'Não foi possível excluir o menu.' );
				}

				return array(
					'data'    => array( 'menu_id' => $menu_id ),
					'message' => 'Menu excluído com sucesso.',
				);

			default:
				throw new RuntimeException(
					sprintf( 'Operação "%s" inválida para manage_menus. Use: list, create, add_item, delete.', esc_html( $operation ) )
				);
		}
	}

	/**
	 * 24. manage_widgets — Lista sidebars e widgets.
	 */
	private static function manage_widgets( array $params ): array {

		global $wp_registered_sidebars, $wp_registered_widgets;

		$sidebars_widgets = wp_get_sidebars_widgets();
		$data             = array();

		foreach ( $wp_registered_sidebars as $sidebar_id => $sidebar ) {
			$widgets = array();

			if ( ! empty( $sidebars_widgets[ $sidebar_id ] ) ) {
				foreach ( $sidebars_widgets[ $sidebar_id ] as $widget_id ) {
					$widget_info = array(
						'id' => $widget_id,
					);

					if ( isset( $wp_registered_widgets[ $widget_id ] ) ) {
						$widget_info['name']        = $wp_registered_widgets[ $widget_id ]['name'] ?? '';
						$widget_info['description']  = $wp_registered_widgets[ $widget_id ]['description'] ?? '';
						$widget_info['classname']    = $wp_registered_widgets[ $widget_id ]['classname'] ?? '';
					}

					$widgets[] = $widget_info;
				}
			}

			$data[] = array(
				'sidebar_id'  => $sidebar_id,
				'name'        => $sidebar['name'],
				'description' => $sidebar['description'] ?? '',
				'widgets'     => $widgets,
			);
		}

		return array( 'data' => $data );
	}

	/**
	 * 25. manage_users — list/create/delete usuários.
	 *
	 * $params['operation']: list | create | delete
	 */
	private static function manage_users( array $params ): array {

		$operation = sanitize_text_field( $params['operation'] ?? 'list' );

		switch ( $operation ) {

			case 'list':
				$args = array(
					'number'  => absint( $params['per_page'] ?? 20 ),
					'paged'   => absint( $params['page'] ?? 1 ),
					'orderby' => sanitize_text_field( $params['orderby'] ?? 'registered' ),
					'order'   => sanitize_text_field( $params['order'] ?? 'DESC' ),
				);

				if ( ! empty( $params['role'] ) ) {
					$args['role'] = sanitize_text_field( $params['role'] );
				}

				if ( ! empty( $params['search'] ) ) {
					$args['search'] = '*' . sanitize_text_field( $params['search'] ) . '*';
				}

				$user_query = new WP_User_Query( $args );
				$users      = array();

				foreach ( $user_query->get_results() as $user ) {
					$users[] = array(
						'ID'           => $user->ID,
						'login'        => $user->user_login,
						'email'        => $user->user_email,
						'display_name' => $user->display_name,
						'roles'        => $user->roles,
						'registered'   => $user->user_registered,
					);
				}

				return array(
					'data' => array(
						'users' => $users,
						'total' => (int) $user_query->get_total(),
					),
				);

			case 'create':
				if ( empty( $params['username'] ) || empty( $params['email'] ) ) {
					throw new RuntimeException( 'Os parâmetros "username" e "email" são obrigatórios.' );
				}

				$user_data = array(
					'user_login' => sanitize_user( $params['username'] ),
					'user_email' => sanitize_email( $params['email'] ),
					'user_pass'  => $params['password'] ?? wp_generate_password( 16, true, true ),
					'role'       => sanitize_text_field( $params['role'] ?? 'subscriber' ),
				);

				if ( ! empty( $params['display_name'] ) ) {
					$user_data['display_name'] = sanitize_text_field( $params['display_name'] );
				}

				if ( ! empty( $params['first_name'] ) ) {
					$user_data['first_name'] = sanitize_text_field( $params['first_name'] );
				}

				if ( ! empty( $params['last_name'] ) ) {
					$user_data['last_name'] = sanitize_text_field( $params['last_name'] );
				}

				$user_id = wp_insert_user( $user_data );

				if ( is_wp_error( $user_id ) ) {
					throw new RuntimeException(
						sprintf( 'Erro ao criar usuário: %s', $user_id->get_error_message() )
					);
				}

				return array(
					'data'    => array( 'user_id' => $user_id ),
					'message' => 'Usuário criado com sucesso.',
				);

			case 'delete':
				if ( empty( $params['user_id'] ) ) {
					throw new RuntimeException( 'O parâmetro "user_id" é obrigatório.' );
				}

				require_once ABSPATH . 'wp-admin/includes/user.php';

				$user_id  = absint( $params['user_id'] );
				$reassign = ! empty( $params['reassign'] ) ? absint( $params['reassign'] ) : null;

				$existing = get_user_by( 'id', $user_id );
				if ( ! $existing ) {
					throw new RuntimeException( sprintf( 'Usuário #%d não encontrado.', $user_id ) );
				}

				$result = wp_delete_user( $user_id, $reassign );

				if ( false === $result ) {
					throw new RuntimeException( sprintf( 'Não foi possível excluir o usuário #%d.', $user_id ) );
				}

				return array(
					'data'    => array( 'user_id' => $user_id ),
					'message' => 'Usuário excluído com sucesso.',
				);

			default:
				throw new RuntimeException(
					sprintf( 'Operação "%s" inválida para manage_users. Use: list, create, delete.', esc_html( $operation ) )
				);
		}
	}

	/* =========================================================================
	 * LOW-LEVEL (8)
	 * ====================================================================== */

	/**
	 * 26. execute_php — Executa código PHP arbitrário via eval().
	 */
	private static function execute_php( array $params ): array {

		if ( empty( $params['code'] ) ) {
			throw new RuntimeException( 'O parâmetro "code" é obrigatório.' );
		}

		$code = $params['code'];

		ob_start();

		try {
			$result = eval( $code );
		} catch ( \Throwable $e ) {
			ob_end_clean();
			throw new RuntimeException(
				sprintf( 'Erro ao executar PHP: %s na linha %d', $e->getMessage(), $e->getLine() )
			);
		}

		$output = ob_get_clean();

		return array(
			'data' => array(
				'return' => $result,
				'output' => $output,
			),
		);
	}

	/**
	 * 27. wp_cli — Executa um comando WP-CLI.
	 */
	private static function wp_cli( array $params ): array {

		if ( empty( $params['command'] ) ) {
			throw new RuntimeException( 'O parâmetro "command" é obrigatório.' );
		}

		$command = $params['command'];

		// Sanitizar: não permitir encadeamento de comandos.
		if ( preg_match( '/[;&|`$]/', $command ) ) {
			throw new RuntimeException( 'Caracteres não permitidos no comando WP-CLI.' );
		}

		$wp_cli_path = defined( 'AMCP_WP_CLI_PATH' )
			? AMCP_WP_CLI_PATH
			: 'wp';

		$wp_path = defined( 'ABSPATH' ) ? ABSPATH : '';

		$full_command = sprintf(
			'%s %s --path=%s --format=json 2>&1',
			escapeshellcmd( $wp_cli_path ),
			$command,
			escapeshellarg( $wp_path )
		);

		$output      = shell_exec( $full_command );
		$json_result = json_decode( $output, true );

		return array(
			'data' => array(
				'raw'    => $output,
				'parsed' => $json_result,
			),
		);
	}

	/**
	 * 28. read_file — Lê um arquivo do sistema de arquivos.
	 */
	private static function read_file( array $params ): array {

		if ( empty( $params['path'] ) ) {
			throw new RuntimeException( 'O parâmetro "path" é obrigatório.' );
		}

		$path = sanitize_text_field( $params['path'] );

		if ( ! file_exists( $path ) ) {
			throw new RuntimeException( sprintf( 'Arquivo "%s" não encontrado.', esc_html( $path ) ) );
		}

		if ( ! is_readable( $path ) ) {
			throw new RuntimeException( sprintf( 'Sem permissão para ler "%s".', esc_html( $path ) ) );
		}

		$content  = file_get_contents( $path );
		$is_binary = false === mb_detect_encoding( $content, 'UTF-8', true );

		return array(
			'data' => array(
				'path'    => $path,
				'content' => $is_binary ? base64_encode( $content ) : $content,
				'binary'  => $is_binary,
				'size'    => filesize( $path ),
			),
		);
	}

	/**
	 * 29. write_file — Grava conteúdo em um arquivo.
	 */
	private static function write_file( array $params ): array {

		if ( empty( $params['path'] ) ) {
			throw new RuntimeException( 'O parâmetro "path" é obrigatório.' );
		}

		if ( ! isset( $params['content'] ) ) {
			throw new RuntimeException( 'O parâmetro "content" é obrigatório.' );
		}

		$path = sanitize_text_field( $params['path'] );
		static::check_protected_path( $path );

		$content = $params['content'];

		// Criar diretório se necessário.
		$dir = dirname( $path );
		if ( ! is_dir( $dir ) ) {
			if ( ! wp_mkdir_p( $dir ) ) {
				throw new RuntimeException( sprintf( 'Não foi possível criar o diretório "%s".', esc_html( $dir ) ) );
			}
		}

		$bytes = file_put_contents( $path, $content );

		if ( false === $bytes ) {
			throw new RuntimeException( sprintf( 'Erro ao gravar em "%s".', esc_html( $path ) ) );
		}

		return array(
			'data' => array(
				'path'  => $path,
				'bytes' => $bytes,
			),
			'message' => 'Arquivo gravado com sucesso.',
		);
	}

	/**
	 * 30. edit_file — Edita um arquivo via str_replace.
	 */
	private static function edit_file( array $params ): array {

		if ( empty( $params['path'] ) ) {
			throw new RuntimeException( 'O parâmetro "path" é obrigatório.' );
		}

		if ( ! isset( $params['search'] ) || ! isset( $params['replace'] ) ) {
			throw new RuntimeException( 'Os parâmetros "search" e "replace" são obrigatórios.' );
		}

		$path = sanitize_text_field( $params['path'] );
		static::check_protected_path( $path );

		if ( ! file_exists( $path ) ) {
			throw new RuntimeException( sprintf( 'Arquivo "%s" não encontrado.', esc_html( $path ) ) );
		}

		$content = file_get_contents( $path );
		if ( false === $content ) {
			throw new RuntimeException( sprintf( 'Erro ao ler "%s".', esc_html( $path ) ) );
		}

		$search  = $params['search'];
		$replace = $params['replace'];

		$count       = 0;
		$new_content = str_replace( $search, $replace, $content, $count );

		if ( 0 === $count ) {
			throw new RuntimeException( 'O texto de busca não foi encontrado no arquivo.' );
		}

		$bytes = file_put_contents( $path, $new_content );

		if ( false === $bytes ) {
			throw new RuntimeException( sprintf( 'Erro ao gravar em "%s".', esc_html( $path ) ) );
		}

		return array(
			'data' => array(
				'path'         => $path,
				'replacements' => $count,
			),
			'message' => sprintf( '%d substituição(ões) realizada(s) com sucesso.', $count ),
		);
	}

	/**
	 * 31. delete_file — Exclui arquivo ou diretório.
	 */
	private static function delete_file( array $params ): array {

		if ( empty( $params['path'] ) ) {
			throw new RuntimeException( 'O parâmetro "path" é obrigatório.' );
		}

		$path = sanitize_text_field( $params['path'] );
		static::check_protected_path( $path );

		if ( ! file_exists( $path ) ) {
			throw new RuntimeException( sprintf( 'Caminho "%s" não encontrado.', esc_html( $path ) ) );
		}

		if ( is_dir( $path ) ) {
			$recursive = ! empty( $params['recursive'] );

			if ( ! $recursive ) {
				throw new RuntimeException(
					'O caminho é um diretório. Defina "recursive" como true para excluí-lo com todo o conteúdo.'
				);
			}

			$result = static::rmdir_recursive( $path );
		} else {
			$result = unlink( $path );
		}

		if ( ! $result ) {
			throw new RuntimeException( sprintf( 'Não foi possível excluir "%s".', esc_html( $path ) ) );
		}

		return array(
			'data'    => array( 'path' => $path ),
			'message' => 'Excluído com sucesso.',
		);
	}

	/**
	 * 32. list_directory — Lista conteúdo de um diretório.
	 */
	private static function list_directory( array $params ): array {

		$path = sanitize_text_field( $params['path'] ?? ABSPATH );

		if ( ! is_dir( $path ) ) {
			throw new RuntimeException( sprintf( 'Diretório "%s" não encontrado.', esc_html( $path ) ) );
		}

		$recursive = ! empty( $params['recursive'] );
		$pattern   = $params['pattern'] ?? '*';
		$items     = array();

		if ( $recursive ) {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $path, RecursiveDirectoryIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::SELF_FIRST
			);

			foreach ( $iterator as $item ) {
				$items[] = array(
					'path'     => $item->getPathname(),
					'name'     => $item->getFilename(),
					'type'     => $item->isDir() ? 'directory' : 'file',
					'size'     => $item->isFile() ? $item->getSize() : null,
					'modified' => gmdate( 'Y-m-d H:i:s', $item->getMTime() ),
				);
			}
		} else {
			$glob_path = rtrim( $path, '/' ) . '/' . $pattern;
			$entries   = glob( $glob_path );

			if ( false === $entries ) {
				$entries = array();
			}

			foreach ( $entries as $entry ) {
				$items[] = array(
					'path'     => $entry,
					'name'     => basename( $entry ),
					'type'     => is_dir( $entry ) ? 'directory' : 'file',
					'size'     => is_file( $entry ) ? filesize( $entry ) : null,
					'modified' => gmdate( 'Y-m-d H:i:s', filemtime( $entry ) ),
				);
			}
		}

		return array(
			'data' => array(
				'path'  => $path,
				'items' => $items,
				'count' => count( $items ),
			),
		);
	}

	/**
	 * 33. query_db — Executa consultas SQL no banco de dados WordPress.
	 */
	private static function query_db( array $params ): array {

		global $wpdb;

		if ( empty( $params['query'] ) ) {
			throw new RuntimeException( 'O parâmetro "query" é obrigatório.' );
		}

		$query = $params['query'];

		// Substituir placeholder {prefix} pelo prefixo real.
		$query = str_replace( '{prefix}', $wpdb->prefix, $query );

		// Detectar tipo de query.
		$trimmed = strtoupper( trim( $query ) );

		if ( 0 === strpos( $trimmed, 'SELECT' ) ) {
			$output_type = sanitize_text_field( $params['output'] ?? 'OBJECT' );

			switch ( strtoupper( $output_type ) ) {
				case 'ARRAY_A':
					$output_const = ARRAY_A;
					break;
				case 'ARRAY_N':
					$output_const = ARRAY_N;
					break;
				default:
					$output_const = OBJECT;
					break;
			}

			$results = $wpdb->get_results( $query, $output_const );

			if ( null === $results && ! empty( $wpdb->last_error ) ) {
				throw new RuntimeException(
					sprintf( 'Erro SQL: %s', $wpdb->last_error )
				);
			}

			return array(
				'data' => array(
					'results'  => $results,
					'num_rows' => $wpdb->num_rows,
				),
			);
		}

		// Mutations (INSERT, UPDATE, DELETE, etc.).
		$result = $wpdb->query( $query );

		if ( false === $result ) {
			throw new RuntimeException(
				sprintf( 'Erro SQL: %s', $wpdb->last_error )
			);
		}

		return array(
			'data' => array(
				'affected_rows' => $result,
				'insert_id'     => $wpdb->insert_id,
			),
			'message' => sprintf( '%d linha(s) afetada(s).', $result ),
		);
	}

	/* =========================================================================
	 * ELEMENTOR (1)
	 * ====================================================================== */

	/**
	 * get_elementor_info — Informações completas do Elementor instalado.
	 */
	private static function get_elementor_info( array $params ): array {
		if ( ! did_action( 'elementor/loaded' ) && ! class_exists( '\Elementor\Plugin' ) ) {
			throw new \RuntimeException( 'Elementor não está instalado ou ativo.' );
		}

		$result = array();

		// 1. Widgets disponíveis
		$widgets_manager = \Elementor\Plugin::instance()->widgets_manager;
		$widgets = $widgets_manager->get_widget_types();
		$widget_list = array();
		foreach ( $widgets as $name => $widget ) {
			$widget_list[] = array(
				'name'       => $name,
				'title'      => $widget->get_title(),
				'categories' => $widget->get_categories(),
			);
		}
		$result['widgets'] = $widget_list;
		$result['widgets_count'] = count( $widget_list );

		// 2. Breakpoints
		$breakpoints_manager = \Elementor\Plugin::instance()->breakpoints;
		$breakpoints = $breakpoints_manager->get_active_breakpoints();
		$bp_list = array();
		foreach ( $breakpoints as $name => $bp ) {
			$bp_list[] = array(
				'name'  => $name,
				'label' => $bp->get_label(),
				'value' => $bp->get_value(),
			);
		}
		$result['breakpoints'] = $bp_list;

		// 3. Cache keys que precisam ser limpas ao modificar _elementor_data
		$result['cache_keys'] = array(
			'post_meta' => array(
				'_elementor_element_cache' => 'HTML renderizado dos widgets (CRITICO - sempre deletar)',
				'_elementor_css'           => 'CSS compilado da página',
				'_elementor_page_assets'   => 'Assets da página',
			),
			'options' => array(
				'_elementor_global_css' => 'CSS global do Elementor',
				'elementor_cache_time'  => 'Timestamp do cache',
			),
			'files' => array(
				'wp-content/uploads/elementor/css/post-{ID}.css' => 'CSS compilado em arquivo',
				'wp-content/uploads/elementor/css/global.css'     => 'CSS global em arquivo',
			),
		);

		// 4. Estrutura de dados do _elementor_data
		$result['data_structure'] = array(
			'format' => 'JSON array of top-level containers',
			'element_schema' => array(
				'id'         => 'string (7 char hex)',
				'elType'     => 'container | widget',
				'widgetType' => 'string (only for widgets, e.g. text-editor, heading, image, html, social-icons)',
				'settings'   => 'object with all widget/container settings',
				'elements'   => 'array of child elements',
				'isInner'    => 'boolean',
			),
			'important_settings' => array(
				'flex_direction', 'flex_align_items', 'flex_justify_content',
				'content_width', 'background_background', 'background_color',
				'padding', 'margin', 'border_radius', 'z_index', 'position',
				'custom_css', '_css_classes', '_title',
				'hide_desktop', 'hide_tablet', 'hide_mobile',
			),
			'dimension_format' => '{"unit": "px", "size": 40, "sizes": []}',
			'spacing_format'   => '{"unit": "px", "top": "0", "right": "0", "bottom": "0", "left": "0", "isLinked": false}',
			'responsive_suffix' => '_tablet, _mobile (append to setting name)',
		);

		// 5. Theme builder conditions
		$conditions = get_option( 'elementor_pro_theme_builder_conditions', array() );
		$result['theme_builder'] = $conditions;

		// 6. Fontes registradas
		try {
			$fonts = \Elementor\Fonts::get_fonts();
			$result['fonts_count'] = count( $fonts );
			$result['fonts_sample'] = array_slice( array_keys( $fonts ), 0, 20 );
		} catch ( \Throwable $e ) {
			$result['fonts_count'] = 0;
		}

		// 7. Gotchas / notas importantes
		$result['gotchas'] = array(
			'Sempre deletar _elementor_element_cache ao modificar _elementor_data',
			'Widgets criados programaticamente (sem editor) NAO renderizam',
			'Para adicionar CSS/JS customizado, usar um widget HTML existente',
			'display:block !important sobrescreve visibility responsiva do Elementor - usar media queries',
			'custom_css do widget usa "selector" como placeholder para .elementor-element-{id}',
			'Elementor 4.x pode nao ter .elementor-widget-container wrapper em text-editor',
			'Ao usar custom_css, SEMPRE adicionar css_classes com classe unica (ex: rn-step-card) para isolar escopo e evitar conflitos entre elementos',
			'Ao traduzir Figma para Elementor, validar fielmente: padding, gap, flex_direction, flex_align_items, flex_justify_content, width, min_height, border_radius, typography e cores — usar metadata do Figma para derivar valores exatos',
		);

		return array( 'data' => $result );
	}

	/* =========================================================================
	 * DIAGNOSTICS (4) — atingindo 38 handlers
	 * ====================================================================== */

	/**
	 * 34. get_site_overview — Visão geral do site WordPress (sem campo 'data' aninhado em excesso).
	 */
	private static function get_site_overview( array $params ): array {

		global $wpdb;

		// Informações básicas.
		$wp_version  = get_bloginfo( 'version' );
		$php_version = phpversion();
		$site_url    = get_site_url();
		$home_url    = get_home_url();

		// Tema ativo.
		$theme = wp_get_theme();

		// Plugins ativos.
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins    = get_plugins();
		$active_plugins = get_option( 'active_plugins', array() );

		$plugins_summary = array(
			'total'  => count( $all_plugins ),
			'active' => count( $active_plugins ),
		);

		// CPTs registrados.
		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$cpts       = array();
		foreach ( $post_types as $pt ) {
			$cpts[] = array(
				'name'  => $pt->name,
				'label' => $pt->label,
			);
		}

		// Taxonomias registradas.
		$taxonomies     = get_taxonomies( array( 'public' => true ), 'objects' );
		$taxonomy_list  = array();
		foreach ( $taxonomies as $tax ) {
			$taxonomy_list[] = array(
				'name'  => $tax->name,
				'label' => $tax->label,
			);
		}

		// Contagem de usuários por role.
		$user_count  = count_users();

		// Tamanho do banco de dados.
		$db_size = 0;
		$tables  = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );

		if ( is_array( $tables ) ) {
			foreach ( $tables as $table ) {
				$db_size += ( $table['Data_length'] ?? 0 ) + ( $table['Index_length'] ?? 0 );
			}
		}

		return array(
			'data' => array(
				'wp_version'  => $wp_version,
				'php_version' => $php_version,
				'site_url'    => $site_url,
				'home_url'    => $home_url,
				'multisite'   => is_multisite(),
				'theme'       => array(
					'name'     => $theme->get( 'Name' ),
					'version'  => $theme->get( 'Version' ),
					'template' => $theme->get_template(),
				),
				'plugins'     => $plugins_summary,
				'post_types'  => $cpts,
				'taxonomies'  => $taxonomy_list,
				'users'       => $user_count,
				'db_size'     => $db_size,
				'db_size_mb'  => round( $db_size / 1048576, 2 ),
				'server'      => php_uname(),
				'memory_limit' => ini_get( 'memory_limit' ),
				'max_upload'   => ini_get( 'upload_max_filesize' ),
			),
		);
	}

	/**
	 * 35. site_health — Executa testes diretos do WP Site Health.
	 */
	private static function site_health( array $params ): array {

		if ( ! class_exists( 'WP_Site_Health' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-site-health.php';
		}

		$health  = WP_Site_Health::get_instance();
		$tests   = WP_Site_Health::get_tests();
		$results = array();

		// Testes diretos (síncronos).
		if ( ! empty( $tests['direct'] ) ) {
			foreach ( $tests['direct'] as $key => $test ) {
				if ( is_callable( $test['test'] ) ) {
					try {
						$result = call_user_func( $test['test'] );
						$results[ $key ] = array(
							'label'       => $result['label'] ?? $key,
							'status'      => $result['status'] ?? 'unknown',
							'badge'       => $result['badge'] ?? array(),
							'description' => $result['description'] ?? '',
							'actions'     => $result['actions'] ?? '',
						);
					} catch ( \Throwable $e ) {
						$results[ $key ] = array(
							'label'  => $key,
							'status' => 'error',
							'description' => $e->getMessage(),
						);
					}
				}
			}
		}

		// Resumo por status.
		$summary = array( 'good' => 0, 'recommended' => 0, 'critical' => 0 );
		foreach ( $results as $r ) {
			$s = $r['status'] ?? 'unknown';
			if ( isset( $summary[ $s ] ) ) {
				$summary[ $s ]++;
			}
		}

		return array(
			'data' => array(
				'tests'   => $results,
				'summary' => $summary,
			),
		);
	}

	/**
	 * 36. clear_cache — Limpa transients e cache de objetos.
	 */
	private static function clear_cache( array $params ): array {

		global $wpdb;

		// Excluir transients expirados.
		$expired = $wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_timeout_%'
			 AND option_value < UNIX_TIMESTAMP()"
		);

		// Excluir os transients correspondentes.
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_%'
			 AND option_name NOT LIKE '_transient_timeout_%'
			 AND REPLACE(option_name, '_transient_', '_transient_timeout_') NOT IN (
			     SELECT option_name FROM (
			         SELECT option_name FROM {$wpdb->options}
			         WHERE option_name LIKE '_transient_timeout_%'
			     ) AS t
			 )"
		);

		// Excluir todos os transients se solicitado.
		$all_transients = 0;
		if ( ! empty( $params['all_transients'] ) ) {
			$all_transients = $wpdb->query(
				"DELETE FROM {$wpdb->options}
				 WHERE option_name LIKE '_transient_%'
				 OR option_name LIKE '_site_transient_%'"
			);
		}

		// Flush do cache de objetos.
		$cache_flushed = wp_cache_flush();

		return array(
			'data' => array(
				'expired_transients_deleted' => (int) $expired,
				'all_transients_deleted'     => (int) $all_transients,
				'object_cache_flushed'       => $cache_flushed,
			),
			'message' => 'Cache limpo com sucesso.',
		);
	}

	/**
	 * 37. optimize_db — Otimiza o banco de dados WordPress.
	 */
	private static function optimize_db( array $params ): array {

		global $wpdb;

		$stats = array();

		// 1. Excluir revisões de posts.
		$revisions = $wpdb->query(
			"DELETE FROM {$wpdb->posts} WHERE post_type = 'revision'"
		);
		$stats['revisions_deleted'] = (int) $revisions;

		// 2. Excluir transients expirados.
		$transients = $wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_timeout_%'
			 AND option_value < UNIX_TIMESTAMP()"
		);

		$transients += $wpdb->query(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE '_transient_%'
			 AND option_name NOT LIKE '_transient_timeout_%'
			 AND REPLACE(option_name, '_transient_', '_transient_timeout_') NOT IN (
			     SELECT option_name FROM (
			         SELECT option_name FROM {$wpdb->options}
			         WHERE option_name LIKE '_transient_timeout_%'
			     ) AS t
			 )"
		);
		$stats['expired_transients_deleted'] = (int) $transients;

		// 3. Excluir comentários spam.
		$spam = $wpdb->query(
			"DELETE FROM {$wpdb->comments} WHERE comment_approved = 'spam'"
		);
		$stats['spam_comments_deleted'] = (int) $spam;

		// 4. Excluir posts na lixeira.
		$trashed = $wpdb->query(
			"DELETE FROM {$wpdb->posts} WHERE post_status = 'trash'"
		);
		$stats['trashed_posts_deleted'] = (int) $trashed;

		// 5. Limpar meta órfãos de posts excluídos.
		$orphan_meta = $wpdb->query(
			"DELETE pm FROM {$wpdb->postmeta} pm
			 LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
			 WHERE p.ID IS NULL"
		);
		$stats['orphan_postmeta_deleted'] = (int) $orphan_meta;

		// 6. Limpar meta órfãos de comentários excluídos.
		$orphan_comment_meta = $wpdb->query(
			"DELETE cm FROM {$wpdb->commentmeta} cm
			 LEFT JOIN {$wpdb->comments} c ON cm.comment_id = c.comment_ID
			 WHERE c.comment_ID IS NULL"
		);
		$stats['orphan_commentmeta_deleted'] = (int) $orphan_comment_meta;

		// 7. OPTIMIZE TABLE em todas as tabelas do WP.
		$tables = $wpdb->get_col( "SHOW TABLES LIKE '{$wpdb->prefix}%'" );
		$optimized = array();

		foreach ( $tables as $table ) {
			$wpdb->query( "OPTIMIZE TABLE `{$table}`" );
			$optimized[] = $table;
		}
		$stats['tables_optimized'] = $optimized;

		return array(
			'data'    => $stats,
			'message' => 'Banco de dados otimizado com sucesso.',
		);
	}

	/**
	 * 38. get_site_health — Alias mantido para retrocompatibilidade.
	 *     Já coberto por site_health (#35). Mantemos a contagem exata ao
	 *     considerar que get_site_overview é um handler distinto (#34).
	 *
	 *     Na prática, os 38 handlers são:
	 *     Content (8) + Themes (4) + Plugins (4) + Media (4) +
	 *     Settings (5) + Low-Level (8) + Diagnostics (4) = 37 nomeados acima + 1 (este alias) = 38.
	 *
	 *     Porém, se o chamador não deseja alias, basta remover este bloco.
	 *     Como o spec pede 38 e já temos exatamente 37 métodos únicos acima,
	 *     este NÃO será um alias duplicado — vamos recontabilizar:
	 *
	 *     CONTAGEM REAL:
	 *     01 create_post        14 install_plugin       27 wp_cli
	 *     02 update_post        15 activate_plugin      28 read_file
	 *     03 delete_post        16 delete_plugin        29 write_file
	 *     04 list_posts         17 upload_media         30 edit_file
	 *     05 get_post           18 bulk_upload_media    31 delete_file
	 *     06 manage_taxonomies  19 list_media           32 list_directory
	 *     07 manage_seo         20 delete_media         33 query_db
	 *     08 manage_post_meta   21 get_options          34 get_site_overview
	 *     09 list_themes        22 update_options       35 site_health
	 *     10 install_theme      23 manage_menus         36 clear_cache
	 *     11 activate_theme     24 manage_widgets       37 optimize_db
	 *     12 customize_theme    25 manage_users
	 *     13 list_plugins       26 execute_php
	 *
	 *     = 37. O 38º é error_log / export_content / search_replace.
	 *     Adicionando search_replace como 38º handler útil:
	 */

	/**
	 * 38. search_replace — Busca e substitui no banco de dados (serialization-aware).
	 */
	private static function search_replace( array $params ): array {

		global $wpdb;

		if ( empty( $params['search'] ) ) {
			throw new RuntimeException( 'O parâmetro "search" é obrigatório.' );
		}

		if ( ! isset( $params['replace'] ) ) {
			throw new RuntimeException( 'O parâmetro "replace" é obrigatório.' );
		}

		$search  = $params['search'];
		$replace = $params['replace'];
		$dry_run = ! empty( $params['dry_run'] );

		$tables = $params['tables'] ?? array();
		if ( empty( $tables ) ) {
			$tables = $wpdb->get_col( "SHOW TABLES LIKE '{$wpdb->prefix}%'" );
		}

		$total_replacements = 0;
		$table_stats        = array();

		foreach ( $tables as $table ) {
			$table = sanitize_text_field( $table );

			// Obter colunas de texto da tabela.
			$columns = $wpdb->get_results( "DESCRIBE `{$table}`", ARRAY_A );
			$text_cols = array();

			foreach ( $columns as $col ) {
				$type = strtolower( $col['Type'] );
				if (
					false !== strpos( $type, 'char' ) ||
					false !== strpos( $type, 'text' ) ||
					false !== strpos( $type, 'blob' ) ||
					'mediumtext' === $type ||
					'longtext' === $type
				) {
					$text_cols[] = $col['Field'];
				}
			}

			if ( empty( $text_cols ) ) {
				continue;
			}

			// Obter primary key.
			$primary_key = null;
			foreach ( $columns as $col ) {
				if ( 'PRI' === $col['Key'] ) {
					$primary_key = $col['Field'];
					break;
				}
			}

			$table_count = 0;

			foreach ( $text_cols as $col_name ) {
				// Contar ocorrências.
				$count = $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(*) FROM `{$table}` WHERE `{$col_name}` LIKE %s",
					'%' . $wpdb->esc_like( $search ) . '%'
				) );

				if ( $count > 0 && ! $dry_run ) {
					if ( $primary_key ) {
						// Buscar linhas afetadas para tratar serialização.
						$rows = $wpdb->get_results( $wpdb->prepare(
							"SELECT `{$primary_key}`, `{$col_name}` FROM `{$table}` WHERE `{$col_name}` LIKE %s",
							'%' . $wpdb->esc_like( $search ) . '%'
						), ARRAY_A );

						foreach ( $rows as $row ) {
							$value     = $row[ $col_name ];
							$unserialized = @unserialize( $value );

							if ( false !== $unserialized || 'b:0;' === $value ) {
								// Dado serializado — tratar recursivamente.
								$new_value = self::search_replace_recursive( $unserialized, $search, $replace );
								$new_value = serialize( $new_value );
							} else {
								$new_value = str_replace( $search, $replace, $value );
							}

							if ( $new_value !== $value ) {
								$wpdb->update(
									$table,
									array( $col_name => $new_value ),
									array( $primary_key => $row[ $primary_key ] )
								);
							}
						}
					} else {
						// Sem PK — substituição direta.
						$wpdb->query( $wpdb->prepare(
							"UPDATE `{$table}` SET `{$col_name}` = REPLACE(`{$col_name}`, %s, %s)
							 WHERE `{$col_name}` LIKE %s",
							$search,
							$replace,
							'%' . $wpdb->esc_like( $search ) . '%'
						) );
					}
				}

				$table_count += (int) $count;
			}

			if ( $table_count > 0 ) {
				$table_stats[ $table ] = $table_count;
				$total_replacements   += $table_count;
			}
		}

		return array(
			'data' => array(
				'search'      => $search,
				'replace'     => $replace,
				'dry_run'     => $dry_run,
				'total_rows'  => $total_replacements,
				'tables'      => $table_stats,
			),
			'message' => $dry_run
				? sprintf( '%d linha(s) seriam afetadas.', $total_replacements )
				: sprintf( '%d linha(s) atualizada(s) com sucesso.', $total_replacements ),
		);
	}

	/**
	 * Substituição recursiva em dados serializados.
	 *
	 * @param mixed  $data    Dados (pode ser array, string, objeto).
	 * @param string $search  Texto a buscar.
	 * @param string $replace Texto de substituição.
	 * @return mixed
	 */
	private static function search_replace_recursive( $data, string $search, string $replace ) {

		if ( is_string( $data ) ) {
			return str_replace( $search, $replace, $data );
		}

		if ( is_array( $data ) ) {
			foreach ( $data as $key => $value ) {
				$data[ $key ] = self::search_replace_recursive( $value, $search, $replace );
			}
			return $data;
		}

		if ( is_object( $data ) ) {
			foreach ( get_object_vars( $data ) as $prop => $value ) {
				$data->$prop = self::search_replace_recursive( $value, $search, $replace );
			}
			return $data;
		}

		return $data;
	}
}
