<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AMCP_Abilities {

    private static array $registry = array();

    public static function register_defaults(): void {
        $categories = array(
            'content' => array(
                'label' => 'Gerenciamento de Conteúdo',
                'tools' => array(
                    'create-post'        => 'Criar posts e páginas',
                    'update-post'        => 'Editar posts e páginas existentes',
                    'delete-post'        => 'Deletar posts e páginas',
                    'list-posts'         => 'Listar posts com filtros',
                    'get-post'           => 'Obter post completo por ID',
                    'manage-taxonomies'  => 'Gerenciar categorias, tags e taxonomias',
                    'manage-seo'         => 'Gerenciar meta SEO (Yoast/RankMath)',
                    'manage-post-meta'   => 'Gerenciar meta fields customizados',
                ),
            ),
            'themes' => array(
                'label' => 'Temas e Aparência',
                'tools' => array(
                    'list-themes'      => 'Listar temas instalados',
                    'install-theme'    => 'Instalar temas',
                    'activate-theme'   => 'Ativar temas',
                    'customize-theme'  => 'Modificar opções do customizer',
                ),
            ),
            'plugins' => array(
                'label' => 'Plugins',
                'tools' => array(
                    'list-plugins'     => 'Listar plugins instalados',
                    'install-plugin'   => 'Instalar plugins',
                    'activate-plugin'  => 'Ativar/desativar plugins',
                    'delete-plugin'    => 'Deletar plugins',
                ),
            ),
            'media' => array(
                'label' => 'Mídia',
                'tools' => array(
                    'upload-media'      => 'Upload de arquivos e imagens',
                    'bulk-upload-media' => 'Upload múltiplo de imagens',
                    'list-media'        => 'Listar biblioteca de mídia',
                    'delete-media'      => 'Deletar itens da mídia',
                ),
            ),
            'settings' => array(
                'label' => 'Configurações',
                'tools' => array(
                    'get-options'     => 'Ler configurações do WordPress',
                    'update-options'  => 'Alterar configurações do WordPress',
                    'manage-menus'    => 'Gerenciar menus de navegação',
                    'manage-widgets'  => 'Gerenciar widgets e sidebars',
                    'manage-users'    => 'Gerenciar usuários e roles',
                ),
            ),
            'lowlevel' => array(
                'label' => 'Acesso Low-Level',
                'dangerous' => true,
                'tools' => array(
                    'execute-php'    => 'Executar código PHP no ambiente WordPress',
                    'wp-cli'         => 'Executar comandos WP-CLI',
                    'read-file'      => 'Ler arquivos do servidor',
                    'write-file'     => 'Criar ou sobrescrever arquivos',
                    'edit-file'      => 'Editar parcialmente arquivos existentes',
                    'delete-file'    => 'Deletar arquivos e diretórios',
                    'list-directory' => 'Listar conteúdo de diretórios',
                    'query-db'       => 'Executar queries SQL no banco de dados',
                ),
            ),
            'elementor' => array(
                'label' => 'Elementor',
                'tools' => array(
                    'get-elementor-info' => 'Informações completas do Elementor (widgets, cache, estrutura)',
                ),
            ),
            'diagnostics' => array(
                'label' => 'Diagnóstico e Otimização',
                'tools' => array(
                    'get-site-overview' => 'Visão geral completa do site',
                    'site-health'       => 'Diagnóstico de saúde do site',
                    'clear-cache'       => 'Limpar caches do WordPress',
                    'optimize-db'       => 'Otimizar banco de dados',
                ),
            ),
        );

        self::$registry = $categories;
    }

    public static function get_registry(): array {
        if ( empty( self::$registry ) ) {
            self::register_defaults();
        }
        return self::$registry;
    }

    public static function get_all_tool_names(): array {
        $tools = array();
        foreach ( self::get_registry() as $cat ) {
            $tools = array_merge( $tools, array_keys( $cat['tools'] ) );
        }
        return $tools;
    }

    public static function is_valid_action( string $action ): bool {
        return in_array( $action, self::get_all_tool_names(), true );
    }

    public static function key_can( array $key_row, string $action ): bool {
        $abilities = json_decode( $key_row['abilities'], true );
        if ( ! is_array( $abilities ) || empty( $abilities ) ) {
            return false;
        }
        return in_array( $action, $abilities, true );
    }
}
