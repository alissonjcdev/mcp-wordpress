<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AMCP_Auth {

    public static function generate_key(): array {
        $raw_key = 'amcp_sk_' . bin2hex( random_bytes( 32 ) );
        $hash = hash( 'sha256', $raw_key );
        $prefix = substr( $raw_key, 0, 12 );
        return array(
            'raw_key' => $raw_key,
            'hash'    => $hash,
            'prefix'  => $prefix,
        );
    }

    public static function create_api_key( string $name, int $user_id, array $abilities = array() ): array {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_api_keys';

        $user = get_userdata( $user_id );
        if ( ! $user || ! user_can( $user, 'manage_options' ) ) {
            return array( 'success' => false, 'error' => 'Usuário inválido ou sem permissão de administrador.' );
        }

        $key_data = self::generate_key();

        $wpdb->insert( $table, array(
            'name'       => sanitize_text_field( $name ),
            'key_hash'   => $key_data['hash'],
            'key_prefix' => $key_data['prefix'],
            'user_id'    => $user_id,
            'abilities'  => wp_json_encode( $abilities ),
            'status'     => 'active',
        ));

        return array(
            'success' => true,
            'key_id'  => $wpdb->insert_id,
            'api_key' => $key_data['raw_key'],
        );
    }

    public static function validate_key( string $raw_key ): array|false {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_api_keys';

        $hash = hash( 'sha256', $raw_key );
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM $table WHERE key_hash = %s AND status = 'active'", $hash ),
            ARRAY_A
        );

        if ( ! $row ) {
            return false;
        }

        // Update last_used_at
        $wpdb->update( $table, array( 'last_used_at' => current_time( 'mysql' ) ), array( 'id' => $row['id'] ) );

        return $row;
    }

    public static function impersonate_user( int $user_id ): bool {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return false;
        }
        wp_set_current_user( $user_id );
        return true;
    }

    public static function list_keys(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_api_keys';
        return $wpdb->get_results( "SELECT id, name, key_prefix, user_id, abilities, status, last_used_at, created_at FROM $table ORDER BY created_at DESC", ARRAY_A );
    }

    public static function revoke_key( int $key_id ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_api_keys';
        return (bool) $wpdb->update( $table, array( 'status' => 'revoked' ), array( 'id' => $key_id ) );
    }

    public static function update_key( int $key_id, array $data ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_api_keys';
        $allowed = array();
        if ( isset( $data['name'] ) ) $allowed['name'] = sanitize_text_field( $data['name'] );
        if ( isset( $data['user_id'] ) ) $allowed['user_id'] = absint( $data['user_id'] );
        if ( isset( $data['abilities'] ) ) $allowed['abilities'] = wp_json_encode( $data['abilities'] );
        if ( isset( $data['status'] ) ) $allowed['status'] = sanitize_text_field( $data['status'] );
        if ( empty( $allowed ) ) return false;
        return (bool) $wpdb->update( $table, $allowed, array( 'id' => $key_id ) );
    }

    public static function revoke_all(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_api_keys';
        return (int) $wpdb->query( "UPDATE $table SET status = 'revoked' WHERE status = 'active'" );
    }
}
