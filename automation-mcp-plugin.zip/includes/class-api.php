<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AMCP_Api {

    public static function init(): void {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes(): void {
        register_rest_route( 'automation-mcp/v1', '/execute', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_execute' ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route( 'automation-mcp/v1', '/ping', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_ping' ),
            'permission_callback' => '__return_true',
        ));
    }

    public static function handle_ping( \WP_REST_Request $request ): \WP_REST_Response {
        $api_key_header = $request->get_header( 'X-AMCP-Key' );
        if ( ! $api_key_header ) {
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'missing_key', 'message' => 'Chave API ausente.' ),
            ), 401 );
        }

        $key_row = AMCP_Auth::validate_key( $api_key_header );
        if ( ! $key_row ) {
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'invalid_key', 'message' => 'Chave API inválida ou revogada.' ),
            ), 401 );
        }

        $abilities = json_decode( $key_row['abilities'], true );

        return new \WP_REST_Response( array(
            'success' => true,
            'data'    => array(
                'plugin_version' => AMCP_VERSION,
                'wp_version'     => get_bloginfo( 'version' ),
                'php_version'    => phpversion(),
                'site_name'      => get_bloginfo( 'name' ),
                'abilities'      => is_array( $abilities ) ? count( $abilities ) : 0,
            ),
        ), 200 );
    }

    public static function handle_execute( \WP_REST_Request $request ): \WP_REST_Response {
        // 0. Check plugin enabled
        if ( get_option( 'amcp_enabled' ) !== '1' ) {
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'disabled', 'message' => 'O plugin Automation MCP está desativado.' ),
            ), 503 );
        }

        // 1. Validate API key
        $api_key_header = $request->get_header( 'X-AMCP-Key' );
        if ( ! $api_key_header ) {
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'missing_key', 'message' => 'Chave API ausente no header X-AMCP-Key.' ),
            ), 401 );
        }

        $key_row = AMCP_Auth::validate_key( $api_key_header );
        if ( ! $key_row ) {
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'invalid_key', 'message' => 'Chave API inválida ou revogada.' ),
            ), 401 );
        }

        // 2. Parse action
        $body = $request->get_json_params();
        $action = $body['action'] ?? '';
        $params = $body['params'] ?? array();

        if ( ! $action || ! AMCP_Abilities::is_valid_action( $action ) ) {
            $log_id = AMCP_Logger::log( (int) $key_row['id'], $action ?: 'unknown', $params, 'denied', "Ação '$action' não reconhecida." );
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'invalid_action', 'message' => "A ação '$action' não é reconhecida." ),
                'log_id'  => $log_id,
            ), 400 );
        }

        // 3. Check ability permission
        if ( ! AMCP_Abilities::key_can( $key_row, $action ) ) {
            $log_id = AMCP_Logger::log( (int) $key_row['id'], $action, $params, 'denied', "Habilidade '$action' não habilitada para esta chave." );
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'ability_disabled', 'message' => "A habilidade '$action' não está habilitada para esta chave API." ),
                'log_id'  => $log_id,
            ), 403 );
        }

        // 4. Rate limiting
        $rate_limit = (int) get_option( 'amcp_rate_limit', 100 );
        if ( ! self::check_rate_limit( (int) $key_row['id'], $rate_limit ) ) {
            $log_id = AMCP_Logger::log( (int) $key_row['id'], $action, $params, 'denied', 'Limite de requisições excedido.' );
            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'rate_limited', 'message' => "Limite de $rate_limit requisições por minuto excedido." ),
                'log_id'  => $log_id,
            ), 429 );
        }

        // 5. Impersonate user
        AMCP_Auth::impersonate_user( (int) $key_row['user_id'] );

        // 6. Execute action
        try {
            $result = AMCP_Actions::execute( $action, $params );
            $log_id = AMCP_Logger::log( (int) $key_row['id'], $action, $params, 'success', $result['message'] ?? '' );

            return new \WP_REST_Response( array(
                'success' => true,
                'data'    => $result['data'] ?? $result,
                'log_id'  => $log_id,
            ), 200 );
        } catch ( \Throwable $e ) {
            $log_id = AMCP_Logger::log( (int) $key_row['id'], $action, $params, 'error', $e->getMessage() );

            return new \WP_REST_Response( array(
                'success' => false,
                'error'   => array( 'code' => 'execution_error', 'message' => $e->getMessage() ),
                'log_id'  => $log_id,
            ), 500 );
        }
    }

    private static function check_rate_limit( int $key_id, int $limit ): bool {
        $transient_key = 'amcp_rate_' . $key_id . '_' . gmdate( 'YmdHi' );
        $count = (int) get_transient( $transient_key );

        if ( $count >= $limit ) {
            return false;
        }

        set_transient( $transient_key, $count + 1, 120 );
        return true;
    }
}
