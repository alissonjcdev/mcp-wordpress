<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AMCP_Logger {

    public static function log( int $api_key_id, string $action, $params, string $status, string $message = '' ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_logs';

        $wpdb->insert( $table, array(
            'api_key_id'     => $api_key_id,
            'action'         => $action,
            'params'         => is_string( $params ) ? $params : wp_json_encode( $params ),
            'result_status'  => $status,
            'result_message' => $message,
            'ip_address'     => self::get_client_ip(),
        ));

        return (int) $wpdb->insert_id;
    }

    public static function query( array $filters = array(), int $page = 1, int $per_page = 50 ): array {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_logs';
        $keys_table = $wpdb->prefix . 'amcp_api_keys';

        $where = array( '1=1' );
        $values = array();

        if ( ! empty( $filters['api_key_id'] ) ) {
            $where[] = 'l.api_key_id = %d';
            $values[] = $filters['api_key_id'];
        }

        if ( ! empty( $filters['action'] ) ) {
            $where[] = 'l.action = %s';
            $values[] = $filters['action'];
        }

        if ( ! empty( $filters['status'] ) ) {
            $where[] = 'l.result_status = %s';
            $values[] = $filters['status'];
        }

        if ( ! empty( $filters['since'] ) ) {
            $where[] = 'l.created_at >= %s';
            $values[] = $filters['since'];
        }

        $where_sql = implode( ' AND ', $where );
        $offset = ( $page - 1 ) * $per_page;

        $count_sql = "SELECT COUNT(*) FROM $table l WHERE $where_sql";
        $query_sql = "SELECT l.*, k.name as key_name FROM $table l LEFT JOIN $keys_table k ON l.api_key_id = k.id WHERE $where_sql ORDER BY l.created_at DESC LIMIT %d OFFSET %d";

        $values_with_limit = array_merge( $values, array( $per_page, $offset ) );

        if ( ! empty( $values ) ) {
            $total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) );
            $rows = $wpdb->get_results( $wpdb->prepare( $query_sql, $values_with_limit ), ARRAY_A );
        } else {
            $total = (int) $wpdb->get_var( $count_sql );
            $rows = $wpdb->get_results( $wpdb->prepare( $query_sql, array( $per_page, $offset ) ), ARRAY_A );
        }

        return array(
            'items'    => $rows,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'pages'    => (int) ceil( $total / $per_page ),
        );
    }

    public static function cleanup(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_logs';
        $days = (int) get_option( 'amcp_log_retention', 30 );
        if ( $days <= 0 ) return 0;

        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
        return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE created_at < %s", $cutoff ) );
    }

    public static function clear_all(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'amcp_logs';
        return (int) $wpdb->query( "TRUNCATE TABLE $table" );
    }

    private static function get_client_ip(): string {
        $headers = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' );
        foreach ( $headers as $header ) {
            if ( ! empty( $_SERVER[ $header ] ) ) {
                $ip = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) ) );
                return trim( $ip[0] );
            }
        }
        return '0.0.0.0';
    }
}
