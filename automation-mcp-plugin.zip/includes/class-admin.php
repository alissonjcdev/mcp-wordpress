<?php
/**
 * Automation MCP - Painel Administrativo
 *
 * @package AutomationMCP
 * @author  alissondsgn
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class AMCP_Admin {

    private static string $hook_prefix = '';

    public static function init(): void {
        self::register_menus();
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'admin_init', array( __CLASS__, 'handle_forms' ) );
    }

    /**
     * Registra menus e submenus no painel WordPress.
     */
    private static function register_menus(): void {
        self::$hook_prefix = add_menu_page(
            'Automation MCP',
            'Automation MCP',
            'manage_options',
            'amcp-api-keys',
            array( __CLASS__, 'render_api_keys_page' ),
            'dashicons-rest-api',
            80
        );

        add_submenu_page(
            'amcp-api-keys',
            'Chaves API — Automation MCP',
            'Chaves API',
            'manage_options',
            'amcp-api-keys',
            array( __CLASS__, 'render_api_keys_page' )
        );

        add_submenu_page(
            'amcp-api-keys',
            'Habilidades — Automation MCP',
            'Habilidades',
            'manage_options',
            'amcp-abilities',
            array( __CLASS__, 'render_abilities_page' )
        );

        add_submenu_page(
            'amcp-api-keys',
            'Registros — Automation MCP',
            'Registros',
            'manage_options',
            'amcp-logs',
            array( __CLASS__, 'render_logs_page' )
        );

        add_submenu_page(
            'amcp-api-keys',
            'Configurações — Automation MCP',
            'Configurações',
            'manage_options',
            'amcp-settings',
            array( __CLASS__, 'render_settings_page' )
        );
    }

    /**
     * Carrega CSS e JS apenas nas páginas do plugin.
     */
    public static function enqueue_assets( string $hook ): void {
        $plugin_pages = array(
            'toplevel_page_amcp-api-keys',
            'automation-mcp_page_amcp-abilities',
            'automation-mcp_page_amcp-logs',
            'automation-mcp_page_amcp-settings',
        );

        if ( ! in_array( $hook, $plugin_pages, true ) ) {
            return;
        }

        wp_enqueue_style(
            'amcp-admin-css',
            AMCP_PLUGIN_URL . 'admin/css/admin.css',
            array(),
            AMCP_VERSION
        );

        wp_enqueue_script(
            'amcp-admin-js',
            AMCP_PLUGIN_URL . 'admin/js/admin.js',
            array( 'jquery' ),
            AMCP_VERSION,
            true
        );

        wp_localize_script( 'amcp-admin-js', 'amcp_admin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'amcp_admin_nonce' ),
            'rest_url' => rest_url( 'automation-mcp/v1/' ),
        ) );
    }

    /**
     * Processa submissões de formulários do painel.
     */
    public static function handle_forms(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Criar chave API
        if ( isset( $_POST['amcp_action'] ) && $_POST['amcp_action'] === 'create_key' ) {
            check_admin_referer( 'amcp_create_key', 'amcp_nonce' );

            $name      = sanitize_text_field( wp_unslash( $_POST['key_name'] ?? '' ) );
            $user_id   = absint( $_POST['key_user_id'] ?? 0 );
            $abilities = isset( $_POST['key_abilities'] ) && is_array( $_POST['key_abilities'] )
                ? array_map( 'sanitize_text_field', $_POST['key_abilities'] )
                : array();

            if ( empty( $name ) || empty( $user_id ) ) {
                add_settings_error( 'amcp_messages', 'amcp_error', 'Nome e usuário são obrigatórios.', 'error' );
                return;
            }

            $result = AMCP_Auth::create_api_key( $name, $user_id, $abilities );

            if ( $result['success'] ) {
                set_transient( 'amcp_new_key_' . get_current_user_id(), $result['api_key'], 60 );
                add_settings_error( 'amcp_messages', 'amcp_created', 'Chave API criada com sucesso!', 'success' );
            } else {
                add_settings_error( 'amcp_messages', 'amcp_error', $result['error'], 'error' );
            }
        }

        // Revogar chave API
        if ( isset( $_POST['amcp_action'] ) && $_POST['amcp_action'] === 'revoke_key' ) {
            check_admin_referer( 'amcp_revoke_key', 'amcp_nonce' );

            $key_id = absint( $_POST['key_id'] ?? 0 );
            if ( $key_id && AMCP_Auth::revoke_key( $key_id ) ) {
                add_settings_error( 'amcp_messages', 'amcp_revoked', 'Chave API revogada com sucesso.', 'success' );
            } else {
                add_settings_error( 'amcp_messages', 'amcp_error', 'Erro ao revogar a chave.', 'error' );
            }
        }

        // Salvar habilidades de uma chave
        if ( isset( $_POST['amcp_action'] ) && $_POST['amcp_action'] === 'save_abilities' ) {
            check_admin_referer( 'amcp_save_abilities', 'amcp_nonce' );

            $key_id    = absint( $_POST['abilities_key_id'] ?? 0 );
            $abilities = isset( $_POST['abilities'] ) && is_array( $_POST['abilities'] )
                ? array_map( 'sanitize_text_field', $_POST['abilities'] )
                : array();

            if ( $key_id ) {
                AMCP_Auth::update_key( $key_id, array( 'abilities' => $abilities ) );
                add_settings_error( 'amcp_messages', 'amcp_saved', 'Habilidades atualizadas com sucesso.', 'success' );
            }
        }

        // Salvar configurações
        if ( isset( $_POST['amcp_action'] ) && $_POST['amcp_action'] === 'save_settings' ) {
            check_admin_referer( 'amcp_save_settings', 'amcp_nonce' );

            $enabled        = isset( $_POST['amcp_enabled'] ) ? '1' : '0';
            $log_retention  = absint( $_POST['amcp_log_retention'] ?? 30 );
            $rate_limit     = absint( $_POST['amcp_rate_limit'] ?? 100 );
            $protected_paths = sanitize_textarea_field( wp_unslash( $_POST['amcp_protected_paths'] ?? '' ) );

            update_option( 'amcp_enabled', $enabled );
            update_option( 'amcp_log_retention', $log_retention );
            update_option( 'amcp_rate_limit', $rate_limit );

            $paths_array = array_filter( array_map( 'trim', explode( "\n", $protected_paths ) ) );
            update_option( 'amcp_protected_paths', wp_json_encode( $paths_array ) );

            add_settings_error( 'amcp_messages', 'amcp_saved', 'Configurações salvas com sucesso.', 'success' );
        }

        // Zona de perigo: revogar todas as chaves
        if ( isset( $_POST['amcp_action'] ) && $_POST['amcp_action'] === 'revoke_all_keys' ) {
            check_admin_referer( 'amcp_danger_zone', 'amcp_nonce' );

            $count = AMCP_Auth::revoke_all();
            add_settings_error( 'amcp_messages', 'amcp_revoked_all', sprintf( '%d chave(s) revogada(s).', $count ), 'success' );
        }

        // Zona de perigo: limpar todos os registros
        if ( isset( $_POST['amcp_action'] ) && $_POST['amcp_action'] === 'clear_all_logs' ) {
            check_admin_referer( 'amcp_danger_zone', 'amcp_nonce' );

            AMCP_Logger::clear_all();
            add_settings_error( 'amcp_messages', 'amcp_cleared', 'Todos os registros foram removidos.', 'success' );
        }
    }

    /**
     * Renderiza a página de Chaves API.
     */
    public static function render_api_keys_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Acesso negado.' );
        }
        include AMCP_PLUGIN_DIR . 'admin/views/page-api-keys.php';
    }

    /**
     * Renderiza a página de Habilidades.
     */
    public static function render_abilities_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Acesso negado.' );
        }
        include AMCP_PLUGIN_DIR . 'admin/views/page-abilities.php';
    }

    /**
     * Renderiza a página de Registros.
     */
    public static function render_logs_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Acesso negado.' );
        }
        include AMCP_PLUGIN_DIR . 'admin/views/page-logs.php';
    }

    /**
     * Renderiza a página de Configurações.
     */
    public static function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Acesso negado.' );
        }
        include AMCP_PLUGIN_DIR . 'admin/views/page-settings.php';
    }
}
