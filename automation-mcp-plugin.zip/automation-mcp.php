<?php
/**
 * Plugin Name: Automation MCP
 * Plugin URI: https://github.com/alissondsgn/automation-mcp-plugin
 * Description: Controle total do WordPress via agentes AI (Claude Code, Cursor, Claude Desktop, Antigravity) usando o protocolo MCP.
 * Version: 1.0.0
 * Author: alissondsgn
 * Author URI: https://github.com/alissondsgn
 * License: GPL-2.0-or-later
 * Text Domain: automation-mcp
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'AMCP_VERSION', '1.0.0' );
define( 'AMCP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AMCP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AMCP_PLUGIN_FILE', __FILE__ );

// Autoload classes
require_once AMCP_PLUGIN_DIR . 'includes/class-installer.php';
require_once AMCP_PLUGIN_DIR . 'includes/class-auth.php';
require_once AMCP_PLUGIN_DIR . 'includes/class-abilities.php';
require_once AMCP_PLUGIN_DIR . 'includes/class-logger.php';
require_once AMCP_PLUGIN_DIR . 'includes/class-actions.php';
require_once AMCP_PLUGIN_DIR . 'includes/class-api.php';
require_once AMCP_PLUGIN_DIR . 'includes/class-admin.php';

// Activation/Deactivation
register_activation_hook( __FILE__, array( 'AMCP_Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AMCP_Installer', 'deactivate' ) );

// Initialize REST API
add_action( 'init', function() {
    AMCP_Api::init();
});

// Initialize Admin
add_action( 'admin_menu', function() {
    AMCP_Admin::init();
});
