# Automation MCP — WordPress Plugin

WordPress plugin that exposes a REST API for full WordPress control via AI agents through the MCP protocol.

## Requirements

- WordPress 6.0+
- PHP 8.0+
- Elementor (optional, for Elementor tools)
- PRO Elements / Elementor Pro (optional, for custom_css)

## Installation

### Via ZIP

```bash
cd ~/automation-mcp-plugin
zip -r ~/automation-mcp-plugin.zip . -x '.git/*'
```

1. In WP Admin, go to **Plugins > Add New > Upload Plugin**
2. Upload `automation-mcp-plugin.zip`
3. Activate the plugin

### Configuration

1. Go to **WP Admin > Automation MCP**
2. In the **API Keys** tab, create a new key
3. Select the abilities the key will have access to
4. Copy the generated key (shown only once)

## Architecture

```
MCP Server (Python)
    |  HTTP POST
    v
REST API: /wp-json/automation-mcp/v1/execute
    |
    v
[Validation Chain]
  |- Plugin active?
  |- API key valid? (SHA-256 hash)
  |- Action allowed? (key abilities)
  |- Rate limit OK? (100 req/min)
  |- User impersonation
    |
    v
AMCP_Actions::execute() -> specific handler
    |
    v
AMCP_Logger::log() -> audit trail
```

## File Structure

```
automation-mcp-plugin/
├── automation-mcp.php              # Entry point, hooks and initialization
├── includes/
│   ├── class-abilities.php         # Tool registry + granular permissions
│   ├── class-actions.php           # 39 action handlers (all business logic)
│   ├── class-api.php               # REST API routes + validation chain
│   ├── class-auth.php              # API key management + user impersonation
│   ├── class-logger.php            # Audit logging to DB
│   ├── class-admin.php             # WordPress admin pages
│   └── class-installer.php         # DB table setup
└── admin/views/                    # Admin page templates
    ├── page-dashboard.php
    ├── page-abilities.php
    ├── page-logs.php
    └── page-settings.php
```

## Actions (39 handlers)

### Content (8)
- `create-post` — Create post/page/CPT
- `update-post` — Update post
- `delete-post` — Delete post
- `list-posts` — List with filters
- `get-post` — Full post by ID
- `manage-taxonomies` — Categories and tags
- `manage-seo` — SEO meta
- `manage-post-meta` — Custom post meta

### Themes (4)
- `list-themes` — List themes
- `install-theme` — Install from repository
- `activate-theme` — Activate theme
- `customize-theme` — Customizer options

### Plugins (4)
- `list-plugins` — List plugins
- `install-plugin` — Install from repository
- `activate-plugin` — Activate/deactivate
- `delete-plugin` — Delete plugin

### Media (4)
- `upload-media` — Upload file
- `bulk-upload-media` — Bulk upload
- `list-media` — List library
- `delete-media` — Delete item

### Settings (5)
- `get-options` — Read WP options
- `update-options` — Update options
- `manage-menus` — Navigation menus
- `manage-widgets` — Widgets and sidebars
- `manage-users` — User CRUD

### Low-Level (8)
- `execute-php` — Execute arbitrary PHP
- `wp-cli` — WP-CLI commands
- `read-file` — Read file
- `write-file` — Write file
- `edit-file` — Text replacement in file
- `delete-file` — Delete file
- `list-directory` — List directory
- `query-db` — Direct SQL on database

### Elementor (1)
- `get-elementor-info` — Widgets, breakpoints, cache keys, rules

### Diagnostics (4)
- `get-site-overview` — Site overview
- `site-health` — Health diagnostics
- `clear-cache` — Clear caches
- `optimize-db` — Optimize database

## Admin UI (pt-BR)

The plugin includes a WordPress admin panel in Portuguese with 4 tabs:

- **API Keys** — Create, revoke and manage keys with granular permissions
- **Abilities** — View all 39 tools organized by category
- **Logs** — Audit logs with filters (action, status, date)
- **Settings** — Rate limit, log retention, protected paths

## Security

| Layer | Implementation |
|-------|---------------|
| Authentication | API keys with SHA-256 hash, `X-AMCP-Key` header |
| Authorization | Granular per-key abilities (JSON array of actions) |
| Rate Limiting | Per-minute bucket via transients (default: 100 req/min) |
| Impersonation | Actions execute as the WP user linked to the key |
| Audit Trail | Every request logged: key, action, params, result, IP |
| Path Protection | Protected paths list against write/edit/delete |
| Low-Level | "dangerous" category requires explicit enablement |

## Elementor — Rules

### Cache (CRITICAL)
When modifying `_elementor_data`, ALWAYS delete:
```php
delete_post_meta($post_id, '_elementor_element_cache');
delete_post_meta($post_id, '_elementor_css');
delete_post_meta($post_id, '_elementor_page_assets');
delete_option('_elementor_global_css');
delete_option('elementor_cache_time');
```

### CSS Classes
When using `custom_css`, ALWAYS add `css_classes` with a unique class to isolate scope.

### Figma Fidelity
Faithfully validate: padding, gap, flex_direction, flex_align_items, flex_justify_content, width, min_height, border_radius, typography and colors.

## License

Private use. Author: alissondsgn
